// ============================================================
// RenovaTech - Datos de ejemplo y utilidades de inventario
// Simula un backend usando localStorage del navegador, para que
// Registrar, Editar y Eliminar realmente cambien el catálogo
// mientras navegas entre las páginas de la aplicación.
// ============================================================

const RENOVA_STORAGE_KEY = "renovatech_productos";

const RENOVA_PRODUCTOS_DEFECTO = 
[
    {
        "codigo": "P001",
        "nombre": "Laptop Lenovo",
        "categoria": "Computadoras",
        "precio": 2500.0,
        "stock": 10,
        "estado": "Disponible"
    },
    {
        "codigo": "P002",
        "nombre": "Mouse Logitech",
        "categoria": "Accesorios",
        "precio": 80.0,
        "stock": 25,
        "estado": "Disponible"
    },
    {
        "codigo": "P003",
        "nombre": "Teclado Redragon",
        "categoria": "Accesorios",
        "precio": 150.0,
        "stock": 0,
        "estado": "Agotado"
    },
    {
        "codigo": "P004",
        "nombre": "Mochila para laptop",
        "categoria": "Accesorios",
        "precio": 141.11,
        "stock": 0,
        "estado": "Agotado"
    },
    {
        "codigo": "P005",
        "nombre": "Webcam Logitech C920",
        "categoria": "Accesorios",
        "precio": 102.25,
        "stock": 0,
        "estado": "Agotado"
    },
    {
        "codigo": "P006",
        "nombre": "Hub USB-C 7 en 1",
        "categoria": "Accesorios",
        "precio": 113.33,
        "stock": 2,
        "estado": "Disponible"
    },
    {
        "codigo": "P007",
        "nombre": "Laptop Asus Vivobook",
        "categoria": "Computadoras",
        "precio": 2677.83,
        "stock": 4,
        "estado": "Disponible"
    },
    {
        "codigo": "P008",
        "nombre": "Impresora Canon Pixma",
        "categoria": "Impresoras",
        "precio": 718.04,
        "stock": 6,
        "estado": "Disponible"
    },
    {
        "codigo": "P009",
        "nombre": "Impresora HP LaserJet",
        "categoria": "Impresoras",
        "precio": 704.03,
        "stock": 3,
        "estado": "Disponible"
    },
    {
        "codigo": "P010",
        "nombre": "Laptop HP Pavilion",
        "categoria": "Computadoras",
        "precio": 2863.4,
        "stock": 8,
        "estado": "Disponible"
    },
    {
        "codigo": "P011",
        "nombre": "Impresora Epson L3250",
        "categoria": "Impresoras",
        "precio": 412.85,
        "stock": 5,
        "estado": "Disponible"
    },
    {
        "codigo": "P012",
        "nombre": "Monitor LG 24''",
        "categoria": "Monitores",
        "precio": 467.83,
        "stock": 7,
        "estado": "Disponible"
    },
    {
        "codigo": "P013",
        "nombre": "Access Point Ubiquiti",
        "categoria": "Redes",
        "precio": 376.64,
        "stock": 9,
        "estado": "Disponible"
    },
    {
        "codigo": "P014",
        "nombre": "Mini PC Intel NUC",
        "categoria": "Computadoras",
        "precio": 2399.24,
        "stock": 4,
        "estado": "Disponible"
    },
    {
        "codigo": "P015",
        "nombre": "Audifonos JBL",
        "categoria": "Accesorios",
        "precio": 176.73,
        "stock": 6,
        "estado": "Disponible"
    },
    {
        "codigo": "P016",
        "nombre": "Monitor AOC 21.5''",
        "categoria": "Monitores",
        "precio": 613.15,
        "stock": 3,
        "estado": "Disponible"
    },
    {
        "codigo": "P017",
        "nombre": "Router TP-Link AX1800",
        "categoria": "Redes",
        "precio": 272.75,
        "stock": 5,
        "estado": "Disponible"
    },
    {
        "codigo": "P018",
        "nombre": "Monitor Samsung 27''",
        "categoria": "Monitores",
        "precio": 547.66,
        "stock": 2,
        "estado": "Disponible"
    },
    {
        "codigo": "P019",
        "nombre": "Cable de red Cat6 (caja)",
        "categoria": "Redes",
        "precio": 144.11,
        "stock": 8,
        "estado": "Disponible"
    },
    {
        "codigo": "P020",
        "nombre": "Repetidor Wifi TP-Link",
        "categoria": "Redes",
        "precio": 165.89,
        "stock": 4,
        "estado": "Disponible"
    }
];

function renovaGetProductos() {
    const raw = localStorage.getItem(RENOVA_STORAGE_KEY);
    if (!raw) {
        renovaSetProductos(RENOVA_PRODUCTOS_DEFECTO);
        return JSON.parse(JSON.stringify(RENOVA_PRODUCTOS_DEFECTO));
    }
    try {
        return JSON.parse(raw);
    } catch (e) {
        renovaSetProductos(RENOVA_PRODUCTOS_DEFECTO);
        return JSON.parse(JSON.stringify(RENOVA_PRODUCTOS_DEFECTO));
    }
}

function renovaSetProductos(lista) {
    localStorage.setItem(RENOVA_STORAGE_KEY, JSON.stringify(lista));
}

function renovaResetProductos() {
    renovaSetProductos(RENOVA_PRODUCTOS_DEFECTO);
}

function renovaBuscarPorCodigo(codigo) {
    return renovaGetProductos().find(p => p.codigo.toLowerCase() === String(codigo).toLowerCase());
}

function renovaExisteCodigo(codigo) {
    return !!renovaBuscarPorCodigo(codigo);
}

function renovaAgregarProducto(p) {
    const lista = renovaGetProductos();
    p.estado = p.stock > 0 ? "Disponible" : "Agotado";
    lista.push(p);
    renovaSetProductos(lista);
}

function renovaActualizarProducto(codigoOriginal, datos) {
    const lista = renovaGetProductos();
    const idx = lista.findIndex(p => p.codigo === codigoOriginal);
    if (idx === -1) return false;
    datos.estado = datos.stock > 0 ? "Disponible" : "Agotado";
    lista[idx] = datos;
    renovaSetProductos(lista);
    return true;
}

function renovaEliminarProducto(codigo) {
    const lista = renovaGetProductos().filter(p => p.codigo !== codigo);
    renovaSetProductos(lista);
}

function renovaEstadisticas() {
    const lista = renovaGetProductos();
    const total = lista.length;
    const disponibles = lista.filter(p => p.stock > 0).length;
    const agotados = total - disponibles;
    const valorInventario = lista.reduce((acc, p) => acc + p.precio * p.stock, 0);
    const stockTotal = lista.reduce((acc, p) => acc + p.stock, 0);
    const disponibilidad = total > 0 ? Math.round((disponibles / total) * 100) : 0;
    return { total, disponibles, agotados, valorInventario, stockTotal, disponibilidad };
}

function renovaFormatoMoneda(valor) {
    return "S/ " + Number(valor).toLocaleString("es-PE", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function renovaFechaActual() {
    const hoy = new Date();
    const texto = hoy.toLocaleDateString("es-PE", { day: "numeric", month: "long", year: "numeric" });
    return texto.charAt(0).toUpperCase() + texto.slice(1);
}

function renovaBadge(estado) {
    const clase = estado === "Disponible" ? "badge-disponible" : "badge-agotado";
    return '<span class="badge ' + clase + '">' + estado + '</span>';
}

function renovaCategoriasUnicas() {
    const lista = renovaGetProductos();
    return [...new Set(lista.map(p => p.categoria))].sort();
}
