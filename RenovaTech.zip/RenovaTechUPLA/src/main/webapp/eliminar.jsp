<%@ page contentType="text/html;charset=UTF-8" language="java" isELIgnored="true" %>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Eliminar producto - RenovaTech</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="css/estilos.css">
    <script src="js/data.js"></script>
</head>
<body class="bg-[#f8fafc] min-h-screen">
    <div class="flex min-h-screen">
        <aside class="sidebar w-64 flex-shrink-0 flex flex-col py-5 px-3 text-sm">
            <div class="flex items-center gap-2 px-3 pb-5 mb-2 border-b border-white/10">
                <div class="w-9 h-9 rounded-lg bg-white/10 flex items-center justify-center text-white"><svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16Z"/><polyline points="3.29 7 12 12 20.71 7"/><line x1="12" y1="22" x2="12" y2="12"/></svg></div>
                <div>
                    <div class="text-white font-bold text-[15px] leading-tight">RenovaTech</div>
                    <div class="text-slate-400 text-[11px] leading-tight">Gestion de inventario</div>
                </div>
            </div>
            <nav class="flex-1 flex flex-col gap-0.5">
                <a href="index.jsp" class="nav-link"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/></svg><span>Inicio</span></a>
                <div class="nav-section">PRODUCTOS</div>
                <a href="registrar.jsp" class="nav-link"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg><span>Registrar producto</span></a>
                <a href="listar.jsp" class="nav-link"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/><line x1="3" y1="6" x2="3.01" y2="6"/><line x1="3" y1="12" x2="3.01" y2="12"/><line x1="3" y1="18" x2="3.01" y2="18"/></svg><span>Listar productos</span></a>
                <a href="buscar.jsp" class="nav-link"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="7"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg><span>Buscar producto</span></a>
                <a href="editar.jsp" class="nav-link"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.12 2.12 0 0 1 3 3L12 15l-4 1 1-4Z"/></svg><span>Editar producto</span></a>
                <a href="eliminar.jsp" class="nav-link active"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6"/><path d="M14 11v6"/><path d="M9 6V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2"/></svg><span>Eliminar producto</span></a>
                <div class="nav-section">REPORTES</div>
                <a href="disponibles.jsp" class="nav-link"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 8v8a2 2 0 0 1-1 1.73l-6 3.46a2 2 0 0 1-2 0l-6-3.46A2 2 0 0 1 3 16V8"/><path d="M3.27 6.96 12 12l8.73-5.04"/><path d="M12 22V12"/><path d="m7 4.5 10 5.77"/></svg><span>Productos disponibles</span></a>
                <a href="resumen.jsp" class="nav-link"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/></svg><span>Resumen de productos</span></a>
                <div class="my-2"></div>
                <a href="informacion.jsp" class="nav-link"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg><span>Informacion</span></a>
            </nav>
            <div class="pt-4 mt-4 border-t border-white/10">
                <div class="px-3 pb-2 text-[10.5px] font-bold tracking-wide text-slate-500">ENTORNO DE DEMOSTRACION</div>
                <a href="index.jsp" class="nav-link"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg><span>Cerrar sesion</span></a>
            </div>
        </aside>
        <div class="flex-1 flex flex-col">
        <header class="flex items-center justify-between px-8 py-4 bg-white border-b border-gray-200">
            <div class="text-sm text-gray-500">
                <span>RenovaTech</span>
                <span class="mx-1.5">&rsaquo;</span>
                <span class="text-gray-800 font-medium">Eliminar producto</span>
            </div>
            <div class="flex items-center gap-4">
                <span id="fechaActual" class="text-sm text-gray-400"></span>
                <div class="h-6 w-px bg-gray-200"></div>
                <div class="flex items-center gap-2">
                    <div class="avatar-circle">JV</div>
                    <div class="leading-tight">
                        <div class="text-sm font-semibold text-gray-800">JORDAN VERA</div>
                        <div class="text-xs text-gray-400">Usuario demo</div>
                    </div>
                </div>
            </div>
        </header>
            <main class="flex-1 px-8 py-8">

                <div class="flex items-center justify-between mb-6">
                    <div>
                        <h1 class="text-2xl font-bold text-gray-900">Eliminar producto</h1>
                        <p class="text-sm text-gray-500 mt-1">Selecciona un producto del listado para eliminarlo.</p>
                    </div>
                    <a href="registrar.jsp" class="px-4 py-2.5 btn-primary-upla text-white rounded-lg text-sm font-medium shadow-sm">+ Registrar producto</a>
                </div>

                <div class="grid grid-cols-1 sm:grid-cols-3 gap-5 mb-6">
                    <div class="card-white p-5"><span id="chTotal" class="text-2xl font-bold text-gray-900">0</span> <span class="text-sm text-gray-500">Productos en total</span></div>
                    <div class="card-white p-5"><span id="chDisp" class="text-2xl font-bold text-gray-900">0</span> <span class="text-sm text-gray-500">Disponibles</span></div>
                    <div class="card-white p-5"><span id="chAgo" class="text-2xl font-bold text-gray-900">0</span> <span class="text-sm text-gray-500">Agotados</span></div>
                </div>

                <div class="flex flex-wrap items-end gap-4 mb-5">
                    <div>
                        <label class="block text-xs font-semibold text-gray-500 mb-1.5">Categoria</label>
                        <select id="fltCategoria" class="px-4 py-2.5 rounded-lg border border-gray-300 text-sm text-gray-700 bg-white min-w-[200px]"></select>
                    </div>
                    <button id="btnFiltrar" class="px-4 py-2.5 border border-gray-300 rounded-lg text-sm font-medium text-gray-700 hover:bg-gray-50">Aplicar filtros</button>
                </div>

                <div class="card-white overflow-hidden">
                    <table class="data-table">
                        <thead><tr><th>Codigo</th><th>Producto</th><th>Categoria</th><th>Precio</th><th>Stock</th><th>Estado</th><th>Acciones</th></tr></thead>
                        <tbody id="tbody"></tbody>
                    </table>
                </div>
                <div class="flex items-center justify-between mt-4">
                    <p id="pagInfo" class="text-xs text-gray-400"></p>
                    <div class="flex items-center gap-2 text-sm">
                        <button id="btnPrev" class="w-8 h-8 rounded-lg border border-gray-300 text-gray-500 hover:bg-gray-50">&lsaquo;</button>
                        <span id="pagLabel" class="text-gray-600 font-medium"></span>
                        <button id="btnNext" class="w-8 h-8 rounded-lg border border-gray-300 text-gray-500 hover:bg-gray-50">&rsaquo;</button>
                    </div>
                </div>

                <div class="bg-blue-50 border border-blue-100 text-blue-700 text-sm px-4 py-3 rounded-lg mt-5">
                    Precios en soles (S/). Edita los datos de un producto o selecciona Eliminar para solicitar la confirmacion.
                </div>

                <div id="modalBackdrop" class="modal-backdrop">
                    <div class="modal-box">
                        <div class="w-11 h-11 rounded-full bg-red-50 text-red-500 flex items-center justify-center mb-4"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6"/><path d="M14 11v6"/><path d="M9 6V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2"/></svg></div>
                        <h3 class="text-lg font-bold text-gray-900 mb-1">Eliminar este producto?</h3>
                        <p class="text-sm text-gray-500 mb-4">El producto se quitara del catalogo y de los reportes de inventario. Esta accion no se puede deshacer.</p>
                        <div class="bg-gray-50 border border-gray-200 rounded-xl p-4 mb-5">
                            <div id="modalNombre" class="font-semibold text-gray-800">-</div>
                            <div id="modalMeta" class="text-sm text-gray-500">-</div>
                            <div class="flex items-center justify-between mt-2">
                                <span id="modalStock" class="text-sm text-gray-500">-</span>
                                <span id="modalBadge"></span>
                            </div>
                        </div>
                        <div class="flex justify-end gap-3">
                            <button id="btnCancelarModal" class="px-5 py-2.5 border border-gray-300 rounded-xl text-sm font-medium text-gray-600 hover:bg-gray-50">Cancelar</button>
                            <button id="btnConfirmarEliminar" class="px-5 py-2.5 bg-red-600 hover:bg-red-700 text-white rounded-xl text-sm font-medium">Eliminar producto</button>
                        </div>
                    </div>
                </div>

            </main>
        </div>
    </div>

    <script>
        document.getElementById("fechaActual").textContent = "Fecha actual: " + renovaFechaActual();
    </script>
    <script>
        const PAGE_SIZE = 3;
        let pagina = 1;
        let codigoAEliminar = null;
        const params = new URLSearchParams(window.location.search);

        const selCat = document.getElementById("fltCategoria");
        selCat.innerHTML = '<option value="">Todas las categorias</option>' +
            renovaCategoriasUnicas().map(c => '<option value="' + c + '">' + c + '</option>').join("");

        function productosFiltrados() {
            const cat = selCat.value;
            return renovaGetProductos().filter(p => !cat || p.categoria === cat);
        }

        function renderStats() {
            const s = renovaEstadisticas();
            document.getElementById("chTotal").textContent = s.total;
            document.getElementById("chDisp").textContent = s.disponibles;
            document.getElementById("chAgo").textContent = s.agotados;
        }

        function renderTabla() {
            const lista = productosFiltrados();
            const totalPaginas = Math.max(1, Math.ceil(lista.length / PAGE_SIZE));
            if (pagina > totalPaginas) pagina = totalPaginas;
            const inicio = (pagina - 1) * PAGE_SIZE;
            const pageItems = lista.slice(inicio, inicio + PAGE_SIZE);

            const tbody = document.getElementById("tbody");
            if (pageItems.length === 0) {
                tbody.innerHTML = '<tr class="empty-row"><td colspan="7">No quedan productos para mostrar.</td></tr>';
            } else {
                tbody.innerHTML = pageItems.map(p => (
                    '<tr>' +
                        '<td class="text-gray-400">' + p.codigo + '</td>' +
                        '<td class="font-semibold text-gray-800">' + p.nombre + '</td>' +
                        '<td>' + p.categoria + '</td>' +
                        '<td>' + p.precio.toFixed(2) + '</td>' +
                        '<td>' + p.stock + '</td>' +
                        '<td>' + renovaBadge(p.estado) + '</td>' +
                        '<td><a class="action-edit" href="editar.jsp?codigo=' + encodeURIComponent(p.codigo) + '">Editar</a>' +
                            '<a class="action-delete" href="#" onclick="abrirModal(\'' + p.codigo + '\');return false;">Eliminar</a></td>' +
                    '</tr>'
                )).join("");
            }
            const desde = lista.length === 0 ? 0 : inicio + 1;
            const hasta = Math.min(inicio + PAGE_SIZE, lista.length);
            document.getElementById("pagInfo").textContent =
                "Mostrando " + desde + "\u2013" + hasta + " de " + lista.length + " productos.";
            document.getElementById("pagLabel").textContent = pagina + " de " + totalPaginas;
            document.getElementById("btnPrev").disabled = pagina <= 1;
            document.getElementById("btnNext").disabled = pagina >= totalPaginas;
        }

        function abrirModal(codigo) {
            const p = renovaBuscarPorCodigo(codigo);
            if (!p) return;
            codigoAEliminar = codigo;
            document.getElementById("modalNombre").textContent = p.nombre;
            document.getElementById("modalMeta").textContent = p.codigo + " \u00b7 " + p.categoria + " \u00b7 S/ " + p.precio.toFixed(2);
            document.getElementById("modalStock").textContent = "Stock: " + p.stock + " unidades";
            document.getElementById("modalBadge").innerHTML = renovaBadge(p.estado);
            document.getElementById("modalBackdrop").classList.add("open");
        }
        function cerrarModal() {
            document.getElementById("modalBackdrop").classList.remove("open");
            codigoAEliminar = null;
        }
        window.abrirModal = abrirModal;

        document.getElementById("btnCancelarModal").addEventListener("click", cerrarModal);
        document.getElementById("btnConfirmarEliminar").addEventListener("click", function () {
            if (codigoAEliminar) {
                renovaEliminarProducto(codigoAEliminar);
                cerrarModal();
                renderStats();
                renderTabla();
            }
        });
        document.getElementById("btnFiltrar").addEventListener("click", function () { pagina = 1; renderTabla(); });
        document.getElementById("btnPrev").addEventListener("click", function () { if (pagina > 1) { pagina--; renderTabla(); } });
        document.getElementById("btnNext").addEventListener("click", function () { pagina++; renderTabla(); });

        renderStats();
        renderTabla();

        const codigoParam = params.get("codigo");
        if (codigoParam && renovaBuscarPorCodigo(codigoParam)) { abrirModal(codigoParam); }
    </script>

</body>
</html>
