<%@ page contentType="text/html;charset=UTF-8" language="java" isELIgnored="true" %>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inicio - RenovaTech</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="css/estilos.css">
    <script src="js/data.js"></script>
</head>
<body class="bg-[#f8fafc] min-h-screen">
    <div class="flex min-h-screen">
        <aside class="sidebar w-64 flex-shrink-0 flex flex-col py-5 px-3 text-sm">
            <div class="flex items-center gap-2 px-3 pb-5 mb-2 border-b border-white/10">
                <div class="w-9 h-9 rounded-lg bg-white/10 flex items-center justify-center text-white"><svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16Z"/><polyline points="3.29 7 12 12 20.71 7"/><line x1="12" y1="22" x2="12" y2="12"/></svg></div>
                <div>
                    <div class="text-white font-bold text-[15px] leading-tight">RenovaTech</div>
                    <div class="text-slate-400 text-[11px] leading-tight">Gestion de inventario</div>
                </div>
            </div>
            <nav class="flex-1 flex flex-col gap-0.5">
                <a href="index.jsp" class="nav-link active"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/></svg><span>Inicio</span></a>
                <div class="nav-section">PRODUCTOS</div>
                <a href="registrar.jsp" class="nav-link"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg><span>Registrar producto</span></a>
                <a href="listar.jsp" class="nav-link"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/><line x1="3" y1="6" x2="3.01" y2="6"/><line x1="3" y1="12" x2="3.01" y2="12"/><line x1="3" y1="18" x2="3.01" y2="18"/></svg><span>Listar productos</span></a>
                <a href="buscar.jsp" class="nav-link"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="7"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg><span>Buscar producto</span></a>
                <a href="editar.jsp" class="nav-link"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.12 2.12 0 0 1 3 3L12 15l-4 1 1-4Z"/></svg><span>Editar producto</span></a>
                <a href="eliminar.jsp" class="nav-link"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6"/><path d="M14 11v6"/><path d="M9 6V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2"/></svg><span>Eliminar producto</span></a>
                <div class="nav-section">REPORTES</div>
                <a href="disponibles.jsp" class="nav-link"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 8v8a2 2 0 0 1-1 1.73l-6 3.46a2 2 0 0 1-2 0l-6-3.46A2 2 0 0 1 3 16V8"/><path d="M3.27 6.96 12 12l8.73-5.04"/><path d="M12 22V12"/><path d="m7 4.5 10 5.77"/></svg><span>Productos disponibles</span></a>
                <a href="resumen.jsp" class="nav-link"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/></svg><span>Resumen de productos</span></a>
                <div class="my-2"></div>
                <a href="informacion.jsp" class="nav-link"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg><span>Informacion</span></a>
            </nav>
            <div class="pt-4 mt-4 border-t border-white/10">
                <div class="px-3 pb-2 text-[10.5px] font-bold tracking-wide text-slate-500">ENTORNO DE DEMOSTRACION</div>
                <a href="index.jsp" class="nav-link"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg><span>Cerrar sesion</span></a>
            </div>
        </aside>
        <div class="flex-1 flex flex-col">
        <header class="flex items-center justify-between px-8 py-4 bg-white border-b border-gray-200">
            <div class="text-sm text-gray-500">
                <span>RenovaTech</span>
                <span class="mx-1.5">&rsaquo;</span>
                <span class="text-gray-800 font-medium">Inicio</span>
            </div>
            <div class="flex items-center gap-4">
                <span id="fechaActual" class="text-sm text-gray-400"></span>
                <div class="h-6 w-px bg-gray-200"></div>
                <div class="flex items-center gap-2">
                    <div class="avatar-circle">JV</div>
                    <div class="leading-tight">
                        <div class="text-sm font-semibold text-gray-800">JORDAN VERA</div>
                        <div class="text-xs text-gray-400">Usuario demo</div>
                    </div>
                </div>
            </div>
        </header>
            <main class="flex-1 px-8 py-8">

                <div class="flex items-center justify-between mb-6">
                    <div>
                        <h1 class="text-2xl font-bold text-gray-900">Inicio</h1>
                        <p class="text-sm text-gray-500 mt-1">Una vista general para organizar tus productos y consultar el inventario.</p>
                    </div>
                    <a href="registrar.jsp" class="px-4 py-2.5 btn-primary-upla text-white rounded-lg text-sm font-medium shadow-sm">+ Registrar producto</a>
                </div>

                <div class="card-blue p-7 mb-6">
                    <span class="text-xs font-bold text-blue-700">RenovaTech</span>
                    <h2 class="text-xl font-bold text-gray-900 mt-1 mb-2">Todo tu inventario, en un solo lugar.</h2>
                    <p class="text-sm text-gray-600 max-w-2xl">Registra, busca y actualiza productos. Consulta su disponibilidad y el valor total del inventario desde un espacio de trabajo sencillo y ordenado.</p>
                    <p id="fechaUsuario" class="text-xs text-blue-700 mt-3 font-medium"></p>
                </div>

                <div class="grid grid-cols-1 md:grid-cols-3 gap-5 mb-6">
                    <div class="card-white p-5">
                        <span class="text-xs font-bold text-gray-500 uppercase tracking-wide">Productos registrados</span>
                        <div id="statTotal" class="text-3xl font-bold text-gray-900 my-1">0</div>
                        <span class="text-xs text-gray-400">Total del catalogo de ejemplo</span>
                    </div>
                    <div class="card-white p-5">
                        <span class="text-xs font-bold text-gray-500 uppercase tracking-wide">Productos disponibles</span>
                        <div id="statDisponibles" class="text-3xl font-bold text-gray-900 my-1">0</div>
                        <span class="text-xs text-gray-400">Con stock mayor que 0</span>
                    </div>
                    <div class="card-white p-5">
                        <span class="text-xs font-bold text-gray-500 uppercase tracking-wide">Valor del inventario</span>
                        <div id="statValor" class="text-3xl font-bold text-gray-900 my-1">S/ 0.00</div>
                        <span id="statUnidades" class="text-xs text-gray-400">0 unidades en total</span>
                    </div>
                </div>

                <div class="grid grid-cols-1 lg:grid-cols-[2fr_1fr] gap-5">
                    <div class="card-white p-6">
                        <h3 class="text-base font-semibold text-gray-900 mb-4">Accesos rapidos</h3>
                        <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
                            <a href="registrar.jsp" class="block p-4 rounded-xl border border-gray-200 hover:border-blue-300 hover:bg-blue-50/40">
                                <div class="text-blue-600 mb-2"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg></div>
                                <div class="text-sm font-semibold text-gray-800">Registrar producto</div>
                                <div class="text-xs text-gray-500 mt-0.5">Anade un producto al catalogo.</div>
                                <div class="text-xs text-blue-600 font-medium mt-2">Abrir &rarr;</div>
                            </a>
                            <a href="buscar.jsp" class="block p-4 rounded-xl border border-gray-200 hover:border-blue-300 hover:bg-blue-50/40">
                                <div class="text-blue-600 mb-2"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="7"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg></div>
                                <div class="text-sm font-semibold text-gray-800">Buscar producto</div>
                                <div class="text-xs text-gray-500 mt-0.5">Encuentra codigo, nombre o categoria.</div>
                                <div class="text-xs text-blue-600 font-medium mt-2">Abrir &rarr;</div>
                            </a>
                            <a href="resumen.jsp" class="block p-4 rounded-xl border border-gray-200 hover:border-blue-300 hover:bg-blue-50/40">
                                <div class="text-blue-600 mb-2"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/></svg></div>
                                <div class="text-sm font-semibold text-gray-800">Resumen de productos</div>
                                <div class="text-xs text-gray-500 mt-0.5">Consulta las cifras del inventario.</div>
                                <div class="text-xs text-blue-600 font-medium mt-2">Abrir &rarr;</div>
                            </a>
                        </div>
                    </div>

                    <div class="card-white p-6">
                        <h3 class="text-base font-semibold text-gray-900 mb-4">Estado del catalogo</h3>
                        <div class="flex items-center justify-between py-2">
                            <span class="text-sm text-gray-600">Con existencias</span>
                            <span id="chipDisponibles" class="badge badge-disponible">0 productos</span>
                        </div>
                        <div class="flex items-center justify-between py-2 border-t border-gray-100">
                            <span class="text-sm text-gray-600">Sin existencias</span>
                            <span id="chipAgotados" class="badge badge-agotado">0 productos</span>
                        </div>
                        <p class="text-xs text-gray-400 mt-3">Los datos mostrados corresponden al conjunto de ejemplo del proyecto.</p>
                    </div>
                </div>

            </main>
        </div>
    </div>

    <script>
        document.getElementById("fechaActual").textContent = "Fecha actual: " + renovaFechaActual();
    </script>
    <script>
        function render() {
            const s = renovaEstadisticas();
            document.getElementById("statTotal").textContent = s.total;
            document.getElementById("statDisponibles").textContent = s.disponibles;
            document.getElementById("statValor").textContent = renovaFormatoMoneda(s.valorInventario);
            document.getElementById("statUnidades").textContent = s.stockTotal + " unidades en total";
            document.getElementById("chipDisponibles").textContent = s.disponibles + " productos";
            document.getElementById("chipAgotados").textContent = s.agotados + " productos";
            document.getElementById("fechaUsuario").textContent = "Fecha actual: " + renovaFechaActual() + " \u00b7 Usuario conectado: JORDAN VERA";
        }
        render();
    </script>

</body>
</html>
