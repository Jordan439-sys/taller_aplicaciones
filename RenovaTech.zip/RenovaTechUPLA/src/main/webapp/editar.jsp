<%@ page contentType="text/html;charset=UTF-8" language="java" isELIgnored="true" %>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar producto - RenovaTech</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="css/estilos.css">
    <script src="js/data.js"></script>
</head>
<body class="bg-[#f8fafc] min-h-screen">
    <div class="flex min-h-screen">
        <aside class="sidebar w-64 flex-shrink-0 flex flex-col py-5 px-3 text-sm">
            <div class="flex items-center gap-2 px-3 pb-5 mb-2 border-b border-white/10">
                <div class="w-9 h-9 rounded-lg bg-white/10 flex items-center justify-center text-white"><svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16Z"/><polyline points="3.29 7 12 12 20.71 7"/><line x1="12" y1="22" x2="12" y2="12"/></svg></div>
                <div>
                    <div class="text-white font-bold text-[15px] leading-tight">RenovaTech</div>
                    <div class="text-slate-400 text-[11px] leading-tight">Gestion de inventario</div>
                </div>
            </div>
            <nav class="flex-1 flex flex-col gap-0.5">
                <a href="index.jsp" class="nav-link"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/></svg><span>Inicio</span></a>
                <div class="nav-section">PRODUCTOS</div>
                <a href="registrar.jsp" class="nav-link"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg><span>Registrar producto</span></a>
                <a href="listar.jsp" class="nav-link"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/><line x1="3" y1="6" x2="3.01" y2="6"/><line x1="3" y1="12" x2="3.01" y2="12"/><line x1="3" y1="18" x2="3.01" y2="18"/></svg><span>Listar productos</span></a>
                <a href="buscar.jsp" class="nav-link"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="7"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg><span>Buscar producto</span></a>
                <a href="editar.jsp" class="nav-link active"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.12 2.12 0 0 1 3 3L12 15l-4 1 1-4Z"/></svg><span>Editar producto</span></a>
                <a href="eliminar.jsp" class="nav-link"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6"/><path d="M14 11v6"/><path d="M9 6V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2"/></svg><span>Eliminar producto</span></a>
                <div class="nav-section">REPORTES</div>
                <a href="disponibles.jsp" class="nav-link"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 8v8a2 2 0 0 1-1 1.73l-6 3.46a2 2 0 0 1-2 0l-6-3.46A2 2 0 0 1 3 16V8"/><path d="M3.27 6.96 12 12l8.73-5.04"/><path d="M12 22V12"/><path d="m7 4.5 10 5.77"/></svg><span>Productos disponibles</span></a>
                <a href="resumen.jsp" class="nav-link"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/></svg><span>Resumen de productos</span></a>
                <div class="my-2"></div>
                <a href="informacion.jsp" class="nav-link"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg><span>Informacion</span></a>
            </nav>
            <div class="pt-4 mt-4 border-t border-white/10">
                <div class="px-3 pb-2 text-[10.5px] font-bold tracking-wide text-slate-500">ENTORNO DE DEMOSTRACION</div>
                <a href="index.jsp" class="nav-link"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg><span>Cerrar sesion</span></a>
            </div>
        </aside>
        <div class="flex-1 flex flex-col">
        <header class="flex items-center justify-between px-8 py-4 bg-white border-b border-gray-200">
            <div class="text-sm text-gray-500">
                <span>RenovaTech</span>
                <span class="mx-1.5">&rsaquo;</span>
                <span class="text-gray-800 font-medium">Editar producto</span>
            </div>
            <div class="flex items-center gap-4">
                <span id="fechaActual" class="text-sm text-gray-400"></span>
                <div class="h-6 w-px bg-gray-200"></div>
                <div class="flex items-center gap-2">
                    <div class="avatar-circle">JV</div>
                    <div class="leading-tight">
                        <div class="text-sm font-semibold text-gray-800">JORDAN VERA</div>
                        <div class="text-xs text-gray-400">Usuario demo</div>
                    </div>
                </div>
            </div>
        </header>
            <main class="flex-1 px-8 py-8">

                <div class="flex items-center justify-between mb-1">
                    <h1 class="text-2xl font-bold text-gray-900">Editar producto</h1>
                    <a href="listar.jsp" class="px-4 py-2 border border-gray-300 rounded-lg text-sm font-medium text-gray-700 hover:bg-gray-50">Volver al listado</a>
                </div>
                <p class="text-sm text-gray-500 mb-6">Actualiza la informacion existente del producto seleccionado.</p>

                <div id="selectorWrap" class="card-white p-5 mb-6 hidden">
                    <label class="block text-sm font-semibold text-gray-700 mb-2">Selecciona un producto para editar</label>
                    <select id="selectorProducto" class="w-full sm:w-96 px-4 py-3 rounded-lg border border-gray-300 text-gray-800 bg-white"></select>
                </div>

                <div id="formWrap" class="grid grid-cols-1 lg:grid-cols-[2fr_1fr] gap-6">
                    <div class="card-white p-7">
                        <h2 class="text-base font-semibold text-gray-900">Datos del producto</h2>
                        <p class="text-sm text-gray-500 mb-5">Los campos con * son obligatorios.</p>

                        <div class="grid grid-cols-1 sm:grid-cols-2 gap-5">
                            <div>
                                <label class="block text-sm font-semibold text-gray-700 mb-2">Codigo *</label>
                                <input type="text" id="eCodigo" class="w-full px-4 py-3 rounded-lg border border-gray-300 outline-none focus:ring-2 focus:ring-blue-500 font-medium text-gray-800">
                                <p class="text-xs text-gray-400 mt-1">Identificador unico del producto.</p>
                            </div>
                            <div>
                                <label class="block text-sm font-semibold text-gray-700 mb-2">Nombre *</label>
                                <input type="text" id="eNombre" class="w-full px-4 py-3 rounded-lg border border-gray-300 outline-none focus:ring-2 focus:ring-blue-500 font-medium text-gray-800">
                                <p class="text-xs text-gray-400 mt-1">Nombre obligatorio.</p>
                            </div>
                            <div>
                                <label class="block text-sm font-semibold text-gray-700 mb-2">Categoria *</label>
                                <select id="eCategoria" class="w-full px-4 py-3 rounded-lg border border-gray-300 outline-none focus:ring-2 focus:ring-blue-500 font-medium text-gray-800 bg-white"></select>
                                <p class="text-xs text-gray-400 mt-1">Categoria obligatoria.</p>
                            </div>
                            <div>
                                <label class="block text-sm font-semibold text-gray-700 mb-2">Estado *</label>
                                <select id="eEstado" class="w-full px-4 py-3 rounded-lg border border-gray-300 outline-none focus:ring-2 focus:ring-blue-500 font-medium text-gray-800 bg-white">
                                    <option value="Disponible">Disponible</option>
                                    <option value="Agotado">Agotado</option>
                                </select>
                                <p class="text-xs text-gray-400 mt-1">Opciones: Disponible / Agotado.</p>
                            </div>
                            <div>
                                <label class="block text-sm font-semibold text-gray-700 mb-2">Precio *</label>
                                <input type="number" id="ePrecio" min="0" step="0.01" class="w-full px-4 py-3 rounded-lg border border-gray-300 outline-none focus:ring-2 focus:ring-blue-500 font-medium text-gray-800">
                                <p class="text-xs text-gray-400 mt-1">Valor decimal mayor que 0. Moneda: soles (S/).</p>
                            </div>
                            <div>
                                <label class="block text-sm font-semibold text-gray-700 mb-2">Stock *</label>
                                <input type="number" id="eStock" min="0" step="1" class="w-full px-4 py-3 rounded-lg border border-gray-300 outline-none focus:ring-2 focus:ring-blue-500 font-medium text-gray-800">
                                <p class="text-xs text-gray-400 mt-1">Numero entero mayor o igual que 0.</p>
                            </div>
                        </div>

                        <div class="flex items-center justify-between mt-7">
                            <p class="text-xs text-gray-400">Revisa los datos antes de guardar.</p>
                            <div class="flex gap-3">
                                <a href="listar.jsp" class="px-5 py-3 border border-gray-300 rounded-xl text-sm font-medium text-gray-600 hover:bg-gray-50">Cancelar</a>
                                <button id="btnGuardarEdit" class="px-5 py-3 btn-primary-upla text-white rounded-xl text-sm font-medium shadow-sm">Guardar cambios</button>
                            </div>
                        </div>
                    </div>

                    <div class="card-white p-6 h-fit">
                        <span class="text-xs font-bold text-gray-400 uppercase tracking-wide">Producto seleccionado</span>
                        <h3 id="selNombre" class="text-lg font-bold text-gray-900 mt-2">-</h3>
                        <p id="selMeta" class="text-sm text-gray-500 mb-2">-</p>
                        <div id="selBadge" class="mb-3"></div>
                        <p class="text-sm text-gray-500">Los datos existentes estan cargados en el formulario. Modifica los campos necesarios y guarda los cambios.</p>
                        <p id="selActual" class="text-sm text-gray-500 mt-3"></p>
                    </div>
                </div>

                <div id="vacioWrap" class="card-white p-10 text-center text-gray-400 hidden">
                    No hay productos registrados todavia. <a href="registrar.jsp" class="text-blue-600 font-medium">Registra uno primero</a>.
                </div>

            </main>
        </div>
    </div>

    <script>
        document.getElementById("fechaActual").textContent = "Fecha actual: " + renovaFechaActual();
    </script>
    <script>
        const params = new URLSearchParams(window.location.search);
        let codigoActual = params.get("codigo");

        const selCat = document.getElementById("eCategoria");
        function llenarCategorias() {
            selCat.innerHTML = '<option value="">Selecciona una categoria</option>' +
                renovaCategoriasUnicas().map(c => '<option value="' + c + '">' + c + '</option>').join("") +
                '<option value="__nueva__">+ Nueva categoria...</option>';
        }

        function cargarSelector(seleccionado) {
            const lista = renovaGetProductos();
            const sel = document.getElementById("selectorProducto");
            sel.innerHTML = lista.map(p => '<option value="' + p.codigo + '">' + p.codigo + ' \u00b7 ' + p.nombre + '</option>').join("");
            if (seleccionado) sel.value = seleccionado;
            sel.onchange = function () { window.location.href = "editar.jsp?codigo=" + encodeURIComponent(sel.value); };
        }

        function cargarProducto(codigo) {
            const p = renovaBuscarPorCodigo(codigo);
            if (!p) return false;
            document.getElementById("eCodigo").value = p.codigo;
            document.getElementById("eNombre").value = p.nombre;
            selCat.value = p.categoria;
            document.getElementById("eEstado").value = p.estado;
            document.getElementById("ePrecio").value = p.precio;
            document.getElementById("eStock").value = p.stock;

            document.getElementById("selNombre").textContent = p.nombre;
            document.getElementById("selMeta").textContent = "Codigo " + p.codigo + " \u00b7 " + p.categoria;
            document.getElementById("selBadge").innerHTML = renovaBadge(p.estado);
            document.getElementById("selActual").textContent =
                "Precio actual: " + renovaFormatoMoneda(p.precio) + "  \u00b7  Stock actual: " + p.stock + " unidades";
            return true;
        }

        llenarCategorias();
        const lista = renovaGetProductos();

        if (lista.length === 0) {
            document.getElementById("formWrap").classList.add("hidden");
            document.getElementById("vacioWrap").classList.remove("hidden");
        } else {
            if (!codigoActual || !renovaBuscarPorCodigo(codigoActual)) {
                codigoActual = lista[0].codigo;
                document.getElementById("selectorWrap").classList.remove("hidden");
            }
            cargarSelector(codigoActual);
            cargarProducto(codigoActual);

            document.getElementById("eStock").addEventListener("input", function () {
                const v = parseFloat(this.value) || 0;
                document.getElementById("eEstado").value = v > 0 ? "Disponible" : "Agotado";
            });

            document.getElementById("btnGuardarEdit").addEventListener("click", function () {
                const nuevoCodigo = document.getElementById("eCodigo").value.trim();
                const nombre = document.getElementById("eNombre").value.trim();
                let categoria = selCat.value;
                const estado = document.getElementById("eEstado").value;
                const precio = parseFloat(document.getElementById("ePrecio").value);
                const stock = parseInt(document.getElementById("eStock").value, 10);

                if (categoria === "__nueva__") { categoria = prompt("Nombre de la nueva categoria:") || ""; }

                if (!nuevoCodigo || !nombre || !categoria || isNaN(precio) || precio <= 0 || isNaN(stock) || stock < 0) {
                    alert("Completa todos los campos obligatorios con valores validos.");
                    return;
                }
                if (nuevoCodigo !== codigoActual && renovaExisteCodigo(nuevoCodigo)) {
                    alert("El codigo " + nuevoCodigo + " ya esta en uso por otro producto.");
                    return;
                }

                renovaActualizarProducto(codigoActual, { codigo: nuevoCodigo, nombre, categoria, precio, stock, estado });
                alert("Cambios guardados correctamente.");
                window.location.href = "listar.jsp";
            });
        }
    </script>

</body>
</html>
