<%@ page contentType="text/html;charset=UTF-8" language="java" isELIgnored="true" %>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Actividad 02 - Empresa de Transportes</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="css/estilos.css">
</head>
<body class="bg-[#f8fafc] min-h-screen py-10 px-4">

    <div class="max-w-6xl mx-auto">
        <div class="flex items-center justify-between mb-8 pb-4 border-b border-gray-200">
            <div>
                <span class="text-xs font-bold text-red-600 tracking-wider">ACTIVIDAD 02</span>
                <h1 class="text-2xl font-bold text-gray-900">Ruta Lima - Huancayo · Pasajes y Obsequios</h1>
                <p class="text-sm text-gray-500">Cálculo de pasajes por turno, descuentos especiales y caramelos de obsequio.</p>
            </div>
            <div class="flex gap-2">
                <a href="index.jsp" class="px-4 py-2 bg-white text-gray-600 border border-gray-200 rounded-lg text-sm font-medium hover:bg-gray-50">Actividad 01 · Tienda</a>
                <a href="transporte.jsp" class="px-4 py-2 bg-blue-600 text-white rounded-lg text-sm font-medium shadow-sm">Actividad 02 · Transporte</a>
            </div>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <div class="bg-white p-8 rounded-2xl shadow-sm border border-gray-200">
                <h2 class="text-base font-semibold text-gray-900 mb-1">1. Datos del Viaje</h2>
                <p class="text-sm text-gray-500 mb-6">Seleccione el turno y cantidad de pasajes.</p>

                <div class="space-y-6">
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-2">Turno del Viaje</label>
                        <select id="turnoSelect" class="w-full px-4 py-3 rounded-lg border border-gray-300 outline-none focus:ring-2 focus:ring-blue-500 font-medium text-gray-800 bg-white">
                            <option value="Mañana">Mañana (S/. 37.50)</option>
                            <option value="Noche">Noche (S/. 37.50)</option>
                        </select>
                    </div>

                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-2">Cantidad de Pasajes Adquiridos</label>
                        <input type="number" id="cantidadPasajes" value="16" step="any" class="w-full px-4 py-3 rounded-lg border border-gray-300 outline-none focus:ring-2 focus:ring-blue-500 font-medium text-gray-800">
                    </div>

                    <button id="btnCalcularTransporte" class="w-full btn-primary-upla text-white font-medium py-3.5 px-6 rounded-xl shadow-md hover:shadow-lg transition-all text-base">
                        Calcular Pasajes y Caramelos
                    </button>
                </div>
            </div>

            <div class="space-y-6">
                <div class="bg-white p-8 rounded-2xl shadow-sm border border-gray-200">
                    <h2 class="text-lg font-semibold text-gray-900 mb-6">2. Resultados de Transporte</h2>

                    <div class="space-y-4">
                        <div class="card-white p-4">
                            <span class="text-xs font-bold text-gray-500 uppercase tracking-wider">Importe de la Compra</span>
                            <div id="resCompraTrans" class="text-xl font-bold text-gray-900 my-1">S/. 600.00</div>
                        </div>

                        <div class="card-blue p-4">
                            <span class="text-xs font-bold text-blue-700 uppercase tracking-wider">Importe del Descuento</span>
                            <div id="resDescuentoTrans" class="text-xl font-bold text-gray-900 my-1">S/. 48.00 (8%)</div>
                        </div>

                        <div class="bg-emerald-50 border border-emerald-200 p-4 rounded-xl">
                            <span class="text-xs font-bold text-emerald-800 uppercase tracking-wider">Importe a Pagar</span>
                            <div id="resPagarTrans" class="text-2xl font-bold text-emerald-900 my-1">S/. 552.00</div>
                        </div>

                        <div class="bg-amber-50 border border-amber-200 p-4 rounded-xl">
                            <span class="text-xs font-bold text-amber-800 uppercase tracking-wider">Caramelos de Obsequio</span>
                            <div id="resCaramelos" class="text-2xl font-bold text-amber-900 my-1">32 caramelos</div>
                            <p class="text-xs text-amber-600">2 por cada boleto (Importe > S/. 200)</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        document.getElementById('btnCalcularTransporte').addEventListener('click', () => {
            const pasajes = parseFloat(document.getElementById('cantidadPasajes').value) || 0;
            const precioPasaje = 37.50;

            const importeCompra = pasajes * precioPasaje;
            const porcentajeDesc = pasajes >= 15 ? 0.08 : 0.05;
            const importeDescuento = importeCompra * porcentajeDesc;
            const importePagar = importeCompra - importeDescuento;

            let caramelosPorBoleto = importePagar > 200 ? 2 : 0;
            const totalCaramelos = pasajes * caramelosPorBoleto;

            document.getElementById('resCompraTrans').innerText = 'S/. ' + importeCompra.toFixed(2);
            document.getElementById('resDescuentoTrans').innerText = 'S/. ' + importeDescuento.toFixed(2) + ' (' + (porcentajeDesc*100).toFixed(0) + '%)';
            document.getElementById('resPagarTrans').innerText = 'S/. ' + importePagar.toFixed(2);
            document.getElementById('resCaramelos').innerText = totalCaramelos + ' caramelos';
        });
    </script>
</body>
</html>
