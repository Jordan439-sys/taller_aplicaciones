<%@ page contentType="text/html;charset=UTF-8" language="java" isELIgnored="true" %>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Actividad 01 - Sistema de Ventas y Obsequios</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="css/estilos.css">
</head>
<body class="bg-[#f8fafc] min-h-screen py-10 px-4">

    <div class="max-w-6xl mx-auto">
        <div class="flex items-center justify-between mb-8 pb-4 border-b border-gray-200">
            <div>
                <span class="text-xs font-bold text-red-600 tracking-wider">ACTIVIDAD 01</span>
                <h1 class="text-2xl font-bold text-gray-900">Control de Ventas, Descuentos y Obsequios</h1>
                <p class="text-sm text-gray-500">Cálculo de importe de compra, descuento por docenas y lapiceros de obsequio.</p>
            </div>
            <div class="flex gap-2">
                <a href="index.jsp" class="px-4 py-2 bg-blue-600 text-white rounded-lg text-sm font-medium shadow-sm">Actividad 01 · Tienda</a>
                <a href="transporte.jsp" class="px-4 py-2 bg-white text-gray-600 border border-gray-200 rounded-lg text-sm font-medium hover:bg-gray-50">Actividad 02 · Transporte</a>
            </div>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <div class="bg-white p-8 rounded-2xl shadow-sm border border-gray-200">
                <h2 class="text-base font-semibold text-gray-900 mb-1">1. Datos de la Compra</h2>
                <p class="text-sm text-gray-500 mb-6">Ingrese los datos del producto y cantidad de docenas.</p>

                <div class="space-y-6">
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-2">Precio de la Docena (S/.)</label>
                        <input type="number" id="precioDocena" value="45.00" step="any" class="w-full px-4 py-3 rounded-lg border border-gray-300 outline-none focus:ring-2 focus:ring-blue-500 font-medium text-gray-800">
                    </div>

                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-2">Cantidad de Docenas Adquiridas</label>
                        <input type="number" id="cantidadDocenas" value="12" step="any" class="w-full px-4 py-3 rounded-lg border border-gray-300 outline-none focus:ring-2 focus:ring-blue-500 font-medium text-gray-800">
                    </div>

                    <button id="btnCalcularTienda" class="w-full btn-primary-upla text-white font-medium py-3.5 px-6 rounded-xl shadow-md hover:shadow-lg transition-all text-base">
                        Calcular Importes y Obsequios
                    </button>
                </div>
            </div>

            <div class="space-y-6">
                <div class="bg-white p-8 rounded-2xl shadow-sm border border-gray-200">
                    <h2 class="text-lg font-semibold text-gray-900 mb-6">2. Resultados Comerciales</h2>

                    <div class="space-y-4">
                        <div class="card-white p-4">
                            <span class="text-xs font-bold text-gray-500 uppercase tracking-wider">Importe de la Compra</span>
                            <div id="resImporteCompra" class="text-xl font-bold text-gray-900 my-1">S/. 540.00</div>
                        </div>

                        <div class="card-blue p-4">
                            <span class="text-xs font-bold text-blue-700 uppercase tracking-wider">Importe del Descuento</span>
                            <div id="resImporteDescuento" class="text-xl font-bold text-gray-900 my-1">S/. 108.00 (20%)</div>
                        </div>

                        <div class="bg-emerald-50 border border-emerald-200 p-4 rounded-xl">
                            <span class="text-xs font-bold text-emerald-800 uppercase tracking-wider">Importe a Pagar</span>
                            <div id="resImportePagar" class="text-2xl font-bold text-emerald-900 my-1">S/. 432.00</div>
                        </div>

                        <div class="bg-purple-50 border border-purple-200 p-4 rounded-xl">
                            <span class="text-xs font-bold text-purple-800 uppercase tracking-wider">Lapiceros de Obsequio</span>
                            <div id="resObsequio" class="text-2xl font-bold text-purple-900 my-1">24 lapiceros</div>
                            <p class="text-xs text-purple-600">2 por cada docena (Importe ≥ S/. 200)</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        document.getElementById('btnCalcularTienda').addEventListener('click', () => {
            const precio = parseFloat(document.getElementById('precioDocena').value) || 0;
            const docenas = parseFloat(document.getElementById('cantidadDocenas').value) || 0;

            const importeCompra = precio * docenas;
            const porcentajeDesc = docenas >= 10 ? 0.20 : 0.10;
            const importeDescuento = importeCompra * porcentajeDesc;
            const importePagar = importeCompra - importeDescuento;

            let lapicerosPorDocena = importePagar >= 200 ? 2 : 0;
            const totalLapiceros = docenas * lapicerosPorDocena;

            document.getElementById('resImporteCompra').innerText = 'S/. ' + importeCompra.toFixed(2);
            document.getElementById('resImporteDescuento').innerText = 'S/. ' + importeDescuento.toFixed(2) + ' (' + (porcentajeDesc*100).toFixed(0) + '%)';
            document.getElementById('resImportePagar').innerText = 'S/. ' + importePagar.toFixed(2);
            document.getElementById('resObsequio').innerText = totalLapiceros + ' lapiceros';
        });
    </script>
</body>
</html>
