<%@ page contentType="text/html;charset=UTF-8" language="java" isELIgnored="true" %>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Crear cuenta - RenovaTech</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="css/estilos.css">
    <script src="js/auth.js"></script>
</head>
<body class="bg-[#f8fafc] min-h-screen flex items-center justify-center p-6">
    <div class="w-full max-w-4xl grid grid-cols-1 md:grid-cols-2 rounded-2xl overflow-hidden shadow-xl bg-white">

        <div class="sidebar p-10 text-white flex flex-col justify-between gap-10">
            <div>
                <div class="flex items-center gap-3 mb-10">
                    <div class="w-11 h-11 rounded-xl bg-white/10 flex items-center justify-center">
                        <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16Z"/><polyline points="3.29 7 12 12 20.71 7"/><line x1="12" y1="22" x2="12" y2="12"/></svg>
                    </div>
                    <div>
                        <div class="font-bold text-lg leading-tight">RenovaTech</div>
                        <div class="text-slate-400 text-xs">Gestión de inventario</div>
                    </div>
                </div>
                <h2 class="text-2xl font-bold leading-snug mb-3">Crea tu cuenta y empieza a comprar.</h2>
                <p class="text-slate-400 text-sm">Regístrate como comprador para ver el catálogo con imágenes, armar tu carrito y finalizar tus compras.</p>
            </div>
            <ul class="text-sm text-slate-300 space-y-2">
                <li>&bull; Elige productos y cantidades según el stock.</li>
                <li>&bull; Paga con el método que prefieras.</li>
                <li>&bull; Consulta tus pedidos en <b class="text-white">Mis compras</b>.</li>
            </ul>
        </div>

        <div class="p-10">
            <h1 class="text-2xl font-bold text-gray-900">Crear cuenta de comprador</h1>
            <p class="text-sm text-gray-500 mt-1 mb-6">Completa tus datos para registrarte.</p>

            <form id="formRegistro" autocomplete="off" novalidate>
                <div class="mb-4">
                    <label class="block text-sm font-semibold text-gray-700 mb-2" for="rNombre">Nombre completo</label>
                    <input type="text" id="rNombre" class="w-full px-4 py-3 rounded-lg border border-gray-300 outline-none focus:ring-2 focus:ring-blue-500 text-gray-800" placeholder="Ej. Ana Torres">
                    <div class="err-campo" id="err-nombre"></div>
                </div>
                <div class="mb-4">
                    <label class="block text-sm font-semibold text-gray-700 mb-2" for="rCorreo">Correo electrónico</label>
                    <input type="email" id="rCorreo" class="w-full px-4 py-3 rounded-lg border border-gray-300 outline-none focus:ring-2 focus:ring-blue-500 text-gray-800" placeholder="correo@ejemplo.com">
                    <div class="err-campo" id="err-correo"></div>
                </div>
                <div class="mb-4">
                    <label class="block text-sm font-semibold text-gray-700 mb-2" for="rUsuario">Usuario</label>
                    <input type="text" id="rUsuario" class="w-full px-4 py-3 rounded-lg border border-gray-300 outline-none focus:ring-2 focus:ring-blue-500 text-gray-800" placeholder="Ej. ana.torres">
                    <div class="err-campo" id="err-usuario"></div>
                </div>
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-5">
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-2" for="rClave">Contraseña</label>
                        <input type="password" id="rClave" class="w-full px-4 py-3 rounded-lg border border-gray-300 outline-none focus:ring-2 focus:ring-blue-500 text-gray-800" placeholder="Mín. 6 caracteres">
                        <div class="err-campo" id="err-clave"></div>
                    </div>
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-2" for="rClave2">Repite la contraseña</label>
                        <input type="password" id="rClave2" class="w-full px-4 py-3 rounded-lg border border-gray-300 outline-none focus:ring-2 focus:ring-blue-500 text-gray-800" placeholder="Repítela">
                        <div class="err-campo" id="err-clave2"></div>
                    </div>
                </div>

                <button type="submit" class="w-full px-5 py-3 btn-primary-upla text-white rounded-xl text-sm font-semibold shadow-sm">Crear cuenta y entrar</button>
            </form>
            <p class="text-center text-sm text-gray-500 mt-4">¿Ya tienes cuenta? <a href="login.jsp" class="text-blue-600 font-semibold">Inicia sesión</a></p>
        </div>
    </div>

    <script>
        if (renovaSesion()) { window.location.replace("index.jsp"); }

        const campos = ["nombre", "correo", "usuario", "clave", "clave2"];
        const ids = { nombre: "rNombre", correo: "rCorreo", usuario: "rUsuario", clave: "rClave", clave2: "rClave2" };

        function limpiarErrores() {
            campos.forEach(function (c) {
                document.getElementById("err-" + c).textContent = "";
                document.getElementById(ids[c]).classList.remove("border-red-400");
            });
        }

        document.getElementById("formRegistro").addEventListener("submit", function (e) {
            e.preventDefault();
            limpiarErrores();
            const datos = {
                nombre: document.getElementById("rNombre").value,
                correo: document.getElementById("rCorreo").value,
                usuario: document.getElementById("rUsuario").value,
                clave: document.getElementById("rClave").value,
                clave2: document.getElementById("rClave2").value
            };
            const r = renovaRegistrarComprador(datos);
            if (!r.ok) {
                document.getElementById("err-" + r.campo).textContent = r.mensaje;
                const input = document.getElementById(ids[r.campo]);
                input.classList.add("border-red-400");
                input.focus();
                return;
            }
            // cuenta creada: se inicia sesión automáticamente y se va al catálogo
            renovaIniciarSesion("comprador", datos.usuario.trim(), datos.clave);
            window.location.href = "listar.jsp";
        });
    </script>
</body>
</html>
