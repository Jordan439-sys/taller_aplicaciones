<%@ page contentType="text/html;charset=UTF-8" language="java" isELIgnored="true" %>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pedidos - RenovaTech</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="css/estilos.css">
    <script src="js/data.js"></script>
    <script src="js/auth.js"></script>
    <script src="js/compras.js"></script>
    <script>renovaProtegerPagina(["administrador", "comprador"]);</script>
</head>
<body class="bg-[#f8fafc] min-h-screen">
    <div class="flex min-h-screen">
        <aside class="sidebar w-64 flex-shrink-0 flex flex-col py-5 px-3 text-sm">
            <div class="flex items-center gap-2 px-3 pb-5 mb-2 border-b border-white/10">
                <div class="w-9 h-9 rounded-lg bg-white/10 flex items-center justify-center text-white"><svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16Z"/><polyline points="3.29 7 12 12 20.71 7"/><line x1="12" y1="22" x2="12" y2="12"/></svg></div>
                <div>
                    <div class="text-white font-bold text-[15px] leading-tight">RenovaTech</div>
                    <div class="text-slate-400 text-[11px] leading-tight">Gestión de inventario</div>
                </div>
            </div>
            <nav class="flex-1 flex flex-col gap-0.5">
                <a href="index.jsp" class="nav-link"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/></svg><span>Inicio</span></a>
                <div class="nav-section">PRODUCTOS</div>
                <a href="registrar.jsp" class="nav-link" data-solo="administrador"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg><span>Registrar producto</span></a>
                <a href="listar.jsp" class="nav-link"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/><line x1="3" y1="6" x2="3.01" y2="6"/><line x1="3" y1="12" x2="3.01" y2="12"/><line x1="3" y1="18" x2="3.01" y2="18"/></svg><span>Listar productos</span></a>
                <a href="buscar.jsp" class="nav-link"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="7"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg><span>Buscar producto</span></a>
                <a href="editar.jsp" class="nav-link" data-solo="administrador"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.12 2.12 0 0 1 3 3L12 15l-4 1 1-4Z"/></svg><span>Editar producto</span></a>
                <a href="eliminar.jsp" class="nav-link" data-solo="administrador"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6"/><path d="M14 11v6"/><path d="M9 6V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2"/></svg><span>Eliminar producto</span></a>
                <div class="nav-section" data-solo="comprador">COMPRAS</div>
                <a href="carrito.jsp" class="nav-link" data-solo="comprador"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"/></svg><span>Carrito</span><span id="cartBadge" class="cart-badge" style="display:none">0</span></a>
                <a href="pedidos.jsp" class="nav-link active" data-solo="comprador"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 5H7a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2h-2"/><rect x="9" y="3" width="6" height="4" rx="1"/><line x1="9" y1="12" x2="15" y2="12"/><line x1="9" y1="16" x2="15" y2="16"/></svg><span>Mis compras</span></a>
                <div class="nav-section">REPORTES</div>
                <a href="disponibles.jsp" class="nav-link"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 8v8a2 2 0 0 1-1 1.73l-6 3.46a2 2 0 0 1-2 0l-6-3.46A2 2 0 0 1 3 16V8"/><path d="M3.27 6.96 12 12l8.73-5.04"/><path d="M12 22V12"/><path d="m7 4.5 10 5.77"/></svg><span>Productos disponibles</span></a>
                <a href="resumen.jsp" class="nav-link" data-solo="administrador"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/></svg><span>Resumen de productos</span></a>
                <a href="pedidos.jsp" class="nav-link active" data-solo="administrador"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 5H7a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2h-2"/><rect x="9" y="3" width="6" height="4" rx="1"/><line x1="9" y1="12" x2="15" y2="12"/><line x1="9" y1="16" x2="15" y2="16"/></svg><span>Pedidos</span></a>
                <div class="my-2"></div>
                <a href="información.jsp" class="nav-link"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg><span>Información</span></a>
            </nav>
            <div class="pt-4 mt-4 border-t border-white/10">
                <div class="px-3 pb-2 text-[10.5px] font-bold tracking-wide text-slate-500">ENTORNO DE DEMOSTRACIÓN</div>
                <a href="login.jsp" class="nav-link" onclick="renovaCerrarSesion()"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg><span>Cerrar sesión</span></a>
            </div>
        </aside>
        <div class="flex-1 flex flex-col">
        <header class="flex items-center justify-between px-8 py-4 bg-white border-b border-gray-200">
            <div class="text-sm text-gray-500">
                <span>RenovaTech</span>
                <span class="mx-1.5">&rsaquo;</span>
                <span class="text-gray-800 font-medium">Pedidos</span>
            </div>
            <div class="flex items-center gap-4">
                <span id="fechaActual" class="text-sm text-gray-400"></span>
                <div class="h-6 w-px bg-gray-200"></div>
                <div class="flex items-center gap-2">
                    <div id="userIniciales" class="avatar-circle">JV</div>
                    <div class="leading-tight">
                        <div id="userNombre" class="text-sm font-semibold text-gray-800">JORDAN VERA</div>
                        <div id="userRol" class="text-xs text-gray-400">Administrador</div>
                    </div>
                </div>
            </div>
        </header>
            <main class="flex-1 px-8 py-8">

                <div class="mb-6">
                    <h1 id="pedTitulo" class="text-2xl font-bold text-gray-900">Pedidos</h1>
                    <p id="pedSub" class="text-sm text-gray-500 mt-1"></p>
                </div>

                <div id="pedNuevo" class="bg-emerald-50 border border-emerald-200 text-emerald-800 text-sm px-4 py-3 rounded-lg mb-5" style="display:none"></div>

                <div data-solo="administrador" class="grid grid-cols-1 sm:grid-cols-3 gap-5 mb-6">
                    <div class="card-white p-5">
                        <span class="text-xs font-bold text-gray-500 uppercase tracking-wide">Pedidos</span>
                        <div id="stPedidos" class="text-3xl font-bold text-gray-900 my-1">0</div>
                        <span class="text-xs text-gray-400">Compras registradas</span>
                    </div>
                    <div class="card-white p-5">
                        <span class="text-xs font-bold text-gray-500 uppercase tracking-wide">Ventas totales</span>
                        <div id="stVentas" class="text-3xl font-bold text-gray-900 my-1">S/ 0.00</div>
                        <span class="text-xs text-gray-400">Suma de todos los pedidos</span>
                    </div>
                    <div class="card-white p-5">
                        <span class="text-xs font-bold text-gray-500 uppercase tracking-wide">Unidades vendidas</span>
                        <div id="stUnidades" class="text-3xl font-bold text-gray-900 my-1">0</div>
                        <span class="text-xs text-gray-400">Productos entregados</span>
                    </div>
                </div>

                <div id="listaPedidos"></div>

                <div class="flex items-center justify-between mt-4">
                    <p id="pagInfo" class="text-xs text-gray-400"></p>
                    <div id="paginador" class="flex items-center gap-1.5 text-sm"></div>
                </div>

            </main>
        </div>
    </div>

    <script>
        document.getElementById("fechaActual").textContent = "Fecha actual: " + renovaFechaActual();
        renovaAplicarRol();
    </script>
    <script>
        const PAGE_SIZE = 5;
        let pagina = 1;
        const s = renovaSesion();
        const esAdmin = s.rol === "administrador";

        document.getElementById("pedTitulo").textContent = esAdmin ? "Pedidos de compra" : "Mis compras";
        document.getElementById("pedSub").textContent = esAdmin
            ? "Compras realizadas por los compradores."
            : "Historial de los pedidos que has realizado.";

        const params = new URLSearchParams(window.location.search);
        const nuevo = params.get("nuevo");
        if (nuevo && !esAdmin) {
            const box = document.getElementById("pedNuevo");
            box.textContent = "¡Compra realizada con éxito! Tu pedido " + nuevo + " fue registrado y el stock se actualizó.";
            box.style.display = "";
        }

        function misPedidos() {
            const todos = renovaGetPedidos().slice().reverse();
            return esAdmin ? todos : todos.filter(p => p.usuario.toLowerCase() === s.usuario.toLowerCase());
        }

        function tarjeta(p) {
            const filas = p.items.map(i =>
                '<div class="flex items-center gap-4 px-5 py-3 border-t border-gray-100">' +
                    '<img class="thumb" style="width:64px;height:48px" src="' + renovaEsc(i.imagen || RENOVA_IMAGEN_GENERICA) + '" alt="" onerror="this.onerror=null;this.src=\'' + RENOVA_IMAGEN_GENERICA + '\'">' +
                    '<div class="flex-1"><div class="font-semibold text-gray-800 text-sm">' + renovaEsc(i.nombre) + '</div>' +
                    '<div class="text-xs text-gray-400">' + renovaEsc(i.codigo) + ' · ' + i.cantidad + ' x S/ ' + Number(i.precio).toFixed(2) + '</div></div>' +
                    '<div class="text-sm font-semibold text-gray-800">S/ ' + (i.precio * i.cantidad).toFixed(2) + '</div>' +
                '</div>').join("");
            const cliente = esAdmin ? ' &middot; Cliente: <b>' + renovaEsc(p.cliente) + '</b> (' + renovaEsc(p.usuario) + ')' : "";
            return '<div class="card-white mb-4 overflow-hidden">' +
                '<div class="flex flex-wrap items-center justify-between gap-2 px-5 py-4 bg-slate-50">' +
                    '<div><div class="font-bold text-gray-900">' + renovaEsc(p.id) + '</div>' +
                    '<div class="text-xs text-gray-500">' + renovaFechaHora(p.fecha) + ' &middot; ' + renovaEsc(p.metodo) + cliente + '</div></div>' +
                    '<div class="text-lg font-bold text-gray-900">' + renovaFormatoMoneda(p.total) + '</div>' +
                '</div>' + filas + '</div>';
        }

        function render() {
            const lista = misPedidos();
            if (esAdmin) {
                const todos = renovaGetPedidos();
                document.getElementById("stPedidos").textContent = todos.length;
                document.getElementById("stVentas").textContent = renovaFormatoMoneda(todos.reduce((a, p) => a + p.total, 0));
                document.getElementById("stUnidades").textContent = todos.reduce((a, p) => a + p.items.reduce((b, i) => b + i.cantidad, 0), 0);
            }
            const totalPaginas = Math.max(1, Math.ceil(lista.length / PAGE_SIZE));
            if (pagina > totalPaginas) pagina = totalPaginas;
            const inicio = (pagina - 1) * PAGE_SIZE;

            document.getElementById("listaPedidos").innerHTML = lista.length
                ? lista.slice(inicio, inicio + PAGE_SIZE).map(tarjeta).join("")
                : '<div class="card-white p-12 text-center"><h2 class="text-lg font-semibold text-gray-800">' +
                    (esAdmin ? "Aún no hay pedidos" : "Todavía no has hecho compras") + '</h2>' +
                    '<p class="text-sm text-gray-500 mt-1 mb-5">' + (esAdmin ? "Cuando un comprador finalice una compra, aparecerá aquí." : "Cuando finalices una compra, aparecerá aquí.") + '</p>' +
                    (esAdmin ? "" : '<a href="listar.jsp" class="inline-block px-5 py-3 btn-primary-upla text-white rounded-xl text-sm font-medium shadow-sm">Ver catálogo</a>') + '</div>';

            const desde = lista.length === 0 ? 0 : inicio + 1;
            const hasta = Math.min(inicio + PAGE_SIZE, lista.length);
            document.getElementById("pagInfo").textContent = "Mostrando " + desde + "\u2013" + hasta + " de " + lista.length + " pedidos";
            renovaRenderPaginador("paginador", pagina, totalPaginas, function (n) { pagina = n; render(); });
        }
        render();
    </script>
</body>
</html>
