// ============================================================
// RenovaTech - Inicio de sesión con dos roles
// Administrador: acceso completo (registrar, editar, eliminar, resumen).
// Comprador: solo consulta (inicio, listar, buscar, disponibles, información).
// IMPORTANTE: es un login de demostración que vive en el navegador
// (sessionStorage). No es seguro para producción: las credenciales están
// en este archivo. En un sistema real se validaría en el servidor.
// ============================================================

const RENOVA_SESION_KEY = "renovatech_sesion";

const RENOVA_USUARIOS = [
    { usuario: "admin",     clave: "12345",     rol: "administrador", nombre: "JORDAN VERA" },
    { usuario: "cliente", clave: "12345", rol: "cliente",     nombre: "jordan vera" }
];

const RENOVA_COMPRADORES_KEY = "renovatech_compradores";

// Compradores que crearon su cuenta desde la página de registro.
function renovaGetCompradores() {
    try {
        const c = JSON.parse(localStorage.getItem(RENOVA_COMPRADORES_KEY));
        return Array.isArray(c) ? c : [];
    } catch (e) {
        return [];
    }
}

function renovaTodosLosUsuarios() {
    return RENOVA_USUARIOS.concat(renovaGetCompradores());
}

// Crea una cuenta de comprador. Devuelve {ok, campo, mensaje} (campo = cuál input falló).
function renovaRegistrarComprador(d) {
    const nombre = String(d.nombre || "").trim().replace(/\s+/g, " ");
    const correo = String(d.correo || "").trim();
    const usuario = String(d.usuario || "").trim();
    const clave = String(d.clave || "");
    if (nombre.length < 3) { return { ok: false, campo: "nombre", mensaje: "Escribe tu nombre completo." }; }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(correo)) { return { ok: false, campo: "correo", mensaje: "Escribe un correo electrónico válido." }; }
    if (!/^[A-Za-z0-9_.]{4,20}$/.test(usuario)) {
        return { ok: false, campo: "usuario", mensaje: "El usuario debe tener de 4 a 20 caracteres (letras, números, punto o guion bajo)." };
    }
    if (clave.length < 6) { return { ok: false, campo: "clave", mensaje: "La contraseña debe tener al menos 6 caracteres." }; }
    if (clave !== String(d.clave2 || "")) { return { ok: false, campo: "clave2", mensaje: "Las contraseñas no coinciden." }; }
    if (renovaTodosLosUsuarios().some(u => u.usuario.toLowerCase() === usuario.toLowerCase())) {
        return { ok: false, campo: "usuario", mensaje: "Ese usuario ya está en uso. Elige otro." };
    }
    const lista = renovaGetCompradores();
    lista.push({ usuario: usuario, clave: clave, correo: correo, nombre: nombre.toUpperCase(), rol: "comprador", creado: new Date().toISOString() });
    localStorage.setItem(RENOVA_COMPRADORES_KEY, JSON.stringify(lista));
    return { ok: true, usuario: usuario };
}

function renovaSesion() {
    try {
        return JSON.parse(sessionStorage.getItem(RENOVA_SESION_KEY));
    } catch (e) {
        return null;
    }
}

function renovaEsAdmin() {
    const s = renovaSesion();
    return !!s && s.rol === "administrador";
}

function renovaIniciarSesion(rol, usuario, clave) {
    const u = renovaTodosLosUsuarios().find(x =>
        x.rol === rol && x.usuario.toLowerCase() === String(usuario).trim().toLowerCase() && x.clave === clave);
    if (!u) {
        return { ok: false, mensaje: "Usuario o contrase\u00f1a incorrectos para el rol seleccionado." };
    }
    sessionStorage.setItem(RENOVA_SESION_KEY, JSON.stringify({ usuario: u.usuario, nombre: u.nombre, rol: u.rol }));
    return { ok: true };
}

function renovaCerrarSesion() {
    sessionStorage.removeItem(RENOVA_SESION_KEY);
}

// Se llama en el <head> de cada página: sin sesión vuelve al login;
// con un rol no permitido vuelve al inicio.
function renovaProtegerPagina(rolesPermitidos) {
    const s = renovaSesion();
    if (!s) { window.location.replace("login.jsp"); return null; }
    if (rolesPermitidos && rolesPermitidos.length && rolesPermitidos.indexOf(s.rol) === -1) {
        window.location.replace("index.jsp");
        return null;
    }
    return s;
}

// Muestra el nombre y rol en el encabezado y oculta lo que no corresponde al rol.
// Los elementos con data-solo="administrador" o data-solo="comprador" solo se ven con ese rol.
function renovaAplicarRol() {
    const s = renovaSesion();
    if (!s) { return; }
    const partes = s.nombre.split(" ");
    const iniciales = (partes[0][0] + (partes[1] ? partes[1][0] : "")).toUpperCase();
    const set = function (id, txt) { const el = document.getElementById(id); if (el) { el.textContent = txt; } };
    set("userNombre", s.nombre);
    set("userRol", s.rol === "administrador" ? "Administrador" : "Comprador");
    set("userIniciales", iniciales);
    if (typeof renovaActualizarBadgeCarrito === "function") { renovaActualizarBadgeCarrito(); }
    document.querySelectorAll("[data-solo]").forEach(function (el) {
        if (el.getAttribute("data-solo") !== s.rol) { el.style.display = "none"; }
    });
}
