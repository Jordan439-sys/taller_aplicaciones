// ============================================================
// RenovaTech - Carrito y pedidos del comprador
// El carrito se guarda por usuario en localStorage. Al finalizar la
// compra se descuenta el stock del catálogo y se guarda el pedido.
// ============================================================

const RENOVA_PEDIDOS_KEY = "renovatech_pedidos";
const RENOVA_CARRITO_PREFIJO = "renovatech_carrito_";

// ---------- Carrito ----------
function renovaClaveCarrito() {
    const s = renovaSesion();
    return s ? RENOVA_CARRITO_PREFIJO + s.usuario.toLowerCase() : null;
}

function renovaGetCarrito() {
    const k = renovaClaveCarrito();
    if (!k) { return []; }
    try {
        const c = JSON.parse(localStorage.getItem(k));
        return Array.isArray(c) ? c : [];
    } catch (e) {
        return [];
    }
}

function renovaSetCarrito(c) {
    const k = renovaClaveCarrito();
    if (k) { localStorage.setItem(k, JSON.stringify(c)); }
    renovaActualizarBadgeCarrito();
}

function renovaUnidadesCarrito() {
    return renovaGetCarrito().reduce(function (a, i) { return a + i.cantidad; }, 0);
}

function renovaActualizarBadgeCarrito() {
    const el = document.getElementById("cartBadge");
    if (!el) { return; }
    const n = renovaUnidadesCarrito();
    el.textContent = n;
    el.style.display = n > 0 ? "inline-block" : "none";
}

function renovaAgregarAlCarrito(codigo, cantidad) {
    cantidad = cantidad || 1;
    const p = renovaBuscarPorCodigo(codigo);
    if (!p) { return { ok: false, mensaje: "El producto ya no existe." }; }
    if (p.stock <= 0) { return { ok: false, mensaje: p.nombre + " está agotado." }; }
    const c = renovaGetCarrito();
    const it = c.find(function (i) { return i.codigo === p.codigo; });
    const nueva = (it ? it.cantidad : 0) + cantidad;
    if (nueva > p.stock) {
        return { ok: false, mensaje: "Solo hay " + p.stock + " unidad(es) de " + p.nombre + "." };
    }
    if (it) { it.cantidad = nueva; } else { c.push({ codigo: p.codigo, cantidad: cantidad }); }
    renovaSetCarrito(c);
    return { ok: true, mensaje: p.nombre + " agregado al carrito." };
}

function renovaCambiarCantidad(codigo, cantidad) {
    const p = renovaBuscarPorCodigo(codigo);
    let c = renovaGetCarrito();
    if (cantidad <= 0 || !p) {
        c = c.filter(function (i) { return i.codigo !== codigo; });
    } else {
        const it = c.find(function (i) { return i.codigo === codigo; });
        if (it) { it.cantidad = Math.min(cantidad, p.stock); }
    }
    renovaSetCarrito(c);
}

function renovaQuitarDelCarrito(codigo) { renovaCambiarCantidad(codigo, 0); }

// Devuelve las líneas del carrito con datos actuales. Quita productos que ya no
// existen o se agotaron y ajusta las cantidades al stock (con avisos).
function renovaDetalleCarrito() {
    const avisos = [];
    const lineas = [];
    const limpio = [];
    renovaGetCarrito().forEach(function (it) {
        const p = renovaBuscarPorCodigo(it.codigo);
        if (!p) { avisos.push("Un producto del carrito ya no está en el catálogo y se quitó."); return; }
        if (p.stock <= 0) { avisos.push(p.nombre + " se agotó y se quitó del carrito."); return; }
        let cant = it.cantidad;
        if (cant > p.stock) {
            cant = p.stock;
            avisos.push("La cantidad de " + p.nombre + " se ajustó a " + p.stock + " por falta de stock.");
        }
        limpio.push({ codigo: p.codigo, cantidad: cant });
        lineas.push({ producto: p, cantidad: cant, subtotal: Math.round(p.precio * cant * 100) / 100 });
    });
    if (avisos.length) { renovaSetCarrito(limpio); }
    const total = Math.round(lineas.reduce(function (a, l) { return a + l.subtotal; }, 0) * 100) / 100;
    const unidades = lineas.reduce(function (a, l) { return a + l.cantidad; }, 0);
    return { lineas: lineas, total: total, unidades: unidades, avisos: avisos };
}

// ---------- Pedidos ----------
function renovaGetPedidos() {
    try {
        const p = JSON.parse(localStorage.getItem(RENOVA_PEDIDOS_KEY));
        return Array.isArray(p) ? p : [];
    } catch (e) {
        return [];
    }
}

// Valida el stock, lo descuenta, guarda el pedido y vacía el carrito.
function renovaFinalizarCompra(metodo) {
    const s = renovaSesion();
    if (!s || s.rol !== "comprador") { return { ok: false, mensaje: "Debes iniciar sesión como comprador." }; }
    const carrito = renovaGetCarrito();
    if (!carrito.length) { return { ok: false, mensaje: "Tu carrito está vacío." }; }
    const productos = renovaGetProductos();
    const items = [];
    for (let k = 0; k < carrito.length; k++) {
        const it = carrito[k];
        const p = productos.find(function (x) { return x.codigo === it.codigo; });
        if (!p) { return { ok: false, mensaje: "Un producto del carrito ya no existe. Revisa tu carrito." }; }
        if (it.cantidad > p.stock) {
            return { ok: false, mensaje: "No hay stock suficiente de " + p.nombre + " (disponible: " + p.stock + ")." };
        }
        items.push({ codigo: p.codigo, nombre: p.nombre, precio: p.precio, cantidad: it.cantidad, imagen: p.imagen });
    }
    items.forEach(function (i) {
        const p = productos.find(function (x) { return x.codigo === i.codigo; });
        p.stock -= i.cantidad;
        p.estado = p.stock > 0 ? "Disponible" : "Agotado";
    });
    renovaSetProductos(productos);

    const pedidos = renovaGetPedidos();
    const num = pedidos.reduce(function (m, p) { return Math.max(m, parseInt(String(p.id).replace("PED-", ""), 10) || 0); }, 0) + 1;
    const pedido = {
        id: "PED-" + String(num).padStart(4, "0"),
        fecha: new Date().toISOString(),
        usuario: s.usuario,
        cliente: s.nombre,
        metodo: metodo,
        items: items,
        total: Math.round(items.reduce(function (a, i) { return a + i.precio * i.cantidad; }, 0) * 100) / 100
    };
    pedidos.push(pedido);
    localStorage.setItem(RENOVA_PEDIDOS_KEY, JSON.stringify(pedidos));
    renovaSetCarrito([]);
    return { ok: true, pedido: pedido };
}

function renovaFechaHora(iso) {
    return new Date(iso).toLocaleString("es-PE", { day: "numeric", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit" });
}

// ---------- Avisos en pantalla ----------
function renovaToast(mensaje, ok, enlaceTexto, enlaceHref) {
    let cont = document.getElementById("toastWrap");
    if (!cont) {
        cont = document.createElement("div");
        cont.id = "toastWrap";
        cont.className = "toast-wrap";
        document.body.appendChild(cont);
    }
    const t = document.createElement("div");
    t.className = "toast" + (ok ? "" : " error");
    const span = document.createElement("span");
    span.textContent = mensaje;
    t.appendChild(span);
    if (enlaceTexto) {
        const a = document.createElement("a");
        a.href = enlaceHref;
        a.textContent = enlaceTexto;
        t.appendChild(a);
    }
    cont.appendChild(t);
    setTimeout(function () { t.remove(); }, 3500);
}

// Botón "Agregar" de las tablas del catálogo.
function renovaClickAgregar(btn) {
    const r = renovaAgregarAlCarrito(btn.getAttribute("data-cod"), 1);
    if (r.ok) { renovaToast(r.mensaje, true, "Ver carrito", "carrito.jsp"); } else { renovaToast(r.mensaje, false); }
}
