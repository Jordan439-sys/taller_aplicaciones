# RenovaTech - Login conectado a SQL Server

Se reemplazó el login de demostración (`sessionStorage` con contraseñas en JavaScript)
por autenticación real contra la base de datos `RenovaTech`.

## 1. Base de datos

Ejecuta primero:

`modelo fisico RENOVATECH(1).sql`

en SQL Server. El script crea la base `RenovaTech` y las cuentas:

- Administrador: `admin` / `admin123`
- Comprador: `comprador` / `comprador123`

## 2. Configurar la conexión

Archivo:

`src/main/java/com/upla/renovatech/config/DatabaseConnection.java`

Por defecto usa:

- servidor: `localhost:1433`
- base de datos: `RenovaTech`
- usuario: `sa`
- contraseña: `TU_PASSWORD_SQLSERVER`

Lo recomendable es usar variables de entorno:

- `RENOVATECH_DB_URL`
- `RENOVATECH_DB_USER`
- `RENOVATECH_DB_PASSWORD`

Si SQL Server está en otra instancia/puerto, cambia `RENOVATECH_DB_URL`.

Ejemplo:

`jdbc:sqlserver://localhost:1433;databaseName=RenovaTech;encrypt=false;trustServerCertificate=true`

## 3. Cómo funciona el login

1. `login.jsp` envía usuario, contraseña y rol mediante POST a `/login`.
2. `LoginServlet` consulta `dbo.Usuario` con `PreparedStatement`.
3. La contraseña se convierte a SHA-256 usando UTF-16LE para coincidir con `HASHBYTES('SHA2_256', N'...')` del SQL.
4. Se valida también el rol y `Activo = 1`.
5. Se crea una `HttpSession` en el servidor.
6. `AuthFilter` protege las páginas según el rol.
7. `/logout` destruye la sesión.

La contraseña ya no está almacenada en `auth.js`.

## 4. Credenciales de SQL Server

No subas a Git la contraseña real. Para desarrollo puedes colocarla temporalmente
en `DatabaseConnection.java`; para producción usa variables de entorno.

## 5. Dependencia agregada

Se agregó el driver oficial JDBC de Microsoft SQL Server:

`com.microsoft.sqlserver:mssql-jdbc:12.8.1.jre11`

El proyecto usa Java 17, por lo que este driver es compatible.
