package com.upla.renovatech.config;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public final class DatabaseConnection {

    public static Connection getConnection() throws SQLException {
        try {
            // Forzamos la carga explícita del driver de SQL Server
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
        } catch (ClassNotFoundException e) {
            throw new SQLException("Error: El driver JDBC de SQL Server no se encuentra en el classpath.", e);
        }

        String url = "jdbc:sqlserver://DESKTOP-O4HD6V1;databaseName=RenovaTech;encrypt=false;trustServerCertificate=true;";
        String user = "sa";
        String password = "1234";
        
        try {
            return DriverManager.getConnection(url, user, password);
        } catch (SQLException e) {
            System.err.println("--- ERROR DE CONEXIÓN SQL SERVER ---");
            e.printStackTrace();
            throw e;
        }
    }
}