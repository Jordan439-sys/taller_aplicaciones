package com.upla.renovatech.web;

import com.upla.renovatech.config.DatabaseConnection;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

@WebServlet("/registro")
public class RegistroServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        request.setCharacterEncoding("UTF-8");

        String usuario = request.getParameter("usuario");
        String clave = request.getParameter("clave");
        String nombre = request.getParameter("nombre");
        String correo = request.getParameter("correo");

        if (usuario == null || clave == null || nombre == null ||
            usuario.isBlank() || clave.isBlank() || nombre.isBlank()) {
            response.sendRedirect("registro.jsp?error=campos");
            return;
        }

        try (Connection cn = DatabaseConnection.getConnection()) {
            // 1. Verificar si el usuario ya existe en la base de datos
            String sqlCheck = "SELECT COUNT(*) FROM dbo.Usuario WHERE NombreUsuario = ?";
            try (PreparedStatement psCheck = cn.prepareStatement(sqlCheck)) {
                psCheck.setString(1, usuario.trim());
                try (ResultSet rs = psCheck.executeQuery()) {
                    if (rs.next() && rs.getInt(1) > 0) {
                        response.sendRedirect("registro.jsp?error=existe");
                        return;
                    }
                }
            }

            // 2. Insertar usando HASHBYTES de SQL Server para que el cifrado sea idéntico al del login
            String sqlInsert = "INSERT INTO dbo.Usuario (NombreUsuario, ClaveHash, NombreCompleto, Correo, IdRol, Activo) VALUES (?, HASHBYTES('SHA2_256', ?), ?, ?, 2, 1)";
            try (PreparedStatement psInsert = cn.prepareStatement(sqlInsert)) {
                psInsert.setString(1, usuario.trim());
                psInsert.setString(2, clave); // SQL Server encripta esto automáticamente igual que en el login
                psInsert.setString(3, nombre.trim());
                psInsert.setString(4, correo != null ? correo.trim() : "");
                psInsert.executeUpdate();
            }

            // 3. Redirigir al login con éxito
            response.sendRedirect("login.jsp?exito=registrado");

        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("registro.jsp?error=conexion");
        }
    }
}