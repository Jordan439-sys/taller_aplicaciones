<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Calculadoras UPLA</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
    <div class="home-wrap">
        <div class="top-header">
            <img src="img/logo.png" alt="Logo UPLA">
        </div>
        <h1 class="home-title">Calculadoras de Geometría</h1>
        <p class="home-sub">Elige una calculadora para resolver y comprender la geometría de forma visual.</p>

        <div class="home-links">
            <a class="home-card card theme-orange" href="rectangulo.jsp">
                <div class="icon-circle">▭</div>
                <h2>Rectángulo</h2>
                <p>Calcula el área y perímetro a partir de la base y la altura.</p>
            </a>

            <a class="home-card card theme-teal" href="hipotenusa.jsp">
                <div class="icon-circle">△</div>
                <h2>Hipotenusa</h2>
                <p>Aplica el teorema de Pitágoras a partir de los dos catetos.</p>
            </a>
        </div>

        <footer class="page-footer">
            <span>&copy; 2026 Universidad Peruana Los Andes</span>
            <a href="#">Soporte institucional</a>
        </footer>
    </div>
</body>
</html>
