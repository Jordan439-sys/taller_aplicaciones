# RenovaTech — catálogo web y SQL Server

## Qué se añadió
- `catalogo.jsp`: catálogo visual adaptable a móvil, búsqueda, filtro por categoría y orden por precio/nombre.
- `css/catalogo.css`: estilos propios del catálogo.
- `ProductosServlet.java`: API `/api/productos` que lee productos de SQL Server y permite alta, edición y baja lógica.
- `DatabaseConnection.java`: conexión JDBC por variables de entorno (ya no lleva una contraseña personal fija en el código).
- Enlace al catálogo desde la navegación de inicio.
- `database/renovatech_primera_instalacion.sql`: copia para instalación inicial sin borrar la base existente.

## 1. Instalar la base de datos
En SQL Server Management Studio, abre y ejecuta `database/renovatech_primera_instalacion.sql` una sola vez. Crea `RenovaTech`, tablas, categorías, productos y usuarios demo. No ejecutes varias veces: las tablas e inserciones no están diseñadas para repetirse.

**Importante:** el archivo SQL original que enviaste contiene un bloque que elimina por completo la base `RenovaTech` antes de recrearla. Esta copia de instalación quita ese bloque destructivo. Haz copia de seguridad si ya tienes datos.

## 2. Configurar conexión
Configura estas variables en el entorno donde corre Tomcat (ajusta servidor, usuario y contraseña):
- `RENOVATECH_DB_URL` — por defecto `jdbc:sqlserver://localhost:1433;databaseName=RenovaTech;encrypt=false;trustServerCertificate=true`
- `RENOVATECH_DB_USER` — por defecto `sa`
- `RENOVATECH_DB_PASSWORD` — obligatoria; no se almacena en el proyecto.

Activa TCP/IP y el puerto TCP de SQL Server (1433 si corresponde), verifica que SQL Server acepte conexiones y concede al usuario permisos sobre `RenovaTech`. No uses una cuenta `sa` en producción; crea un usuario dedicado con permisos mínimos.

Ejemplo en Windows PowerShell para una sesión de desarrollo:
```powershell
$env:RENOVATECH_DB_URL="jdbc:sqlserver://localhost:1433;databaseName=RenovaTech;encrypt=false;trustServerCertificate=true"
$env:RENOVATECH_DB_USER="sa"
$env:RENOVATECH_DB_PASSWORD="TU_CLAVE_REAL"
```
Reinicia Tomcat desde esa misma sesión para que herede las variables.

## 3. Ejecutar
- Proyecto Maven WAR, Java 17 y un servidor compatible con Jakarta Servlet 6 (por ejemplo Tomcat 10.1+).
- Compila desde la carpeta que contiene `pom.xml`: `mvn clean package`.
- Despliega `target/RenovaTech.war` en Tomcat.
- Abre `/RenovaTech/catalogo.jsp`.
- Para acceder al panel y administrar, inicia sesión con la cuenta demo definida en el SQL; cambia las contraseñas demo antes de publicar el sistema.

## API de productos
- `GET /api/productos` — lista productos activos; acepta `q` y `categoria`.
- `POST /api/productos` — inserta producto (requiere sesión de administrador); campos `codigo`, `nombre`, `categoria`, `precio`, `stock`, `imagen`.
- `PUT /api/productos` — actualiza producto (requiere sesión de administrador); mismos campos.
- `DELETE /api/productos?codigo=P001` — baja lógica (requiere sesión de administrador).

El catálogo consulta SQL Server al cargar y filtrar; no depende del `localStorage` para mostrar productos. Las pantallas CRUD antiguas de demostración todavía usan `js/data.js`/`localStorage`; para que todas esas pantallas escriban a SQL Server deben migrarse a la API nueva o a formularios Servlet. La API de persistencia queda preparada para esa integración.

## Limitación de la referencia visual
El enlace de referencia devolvió un error de puerta de enlace al intentar abrirlo desde este entorno, así que el catálogo se diseñó siguiendo un estilo moderno de tienda tecnológica (cabecera, hero, buscador, filtros y tarjetas de producto), no como una copia exacta pixel por pixel.


## Inicio público y pago

La página de entrada del contexto es `catalogo.jsp`. Para una base existente, ejecutar `database/actualizar_datos_pago.sql` una sola vez. El checkout permite seleccionar tarjeta, Yape/Plin o transferencia y registra los datos de referencia en `dbo.Pedido`. En tarjeta se guarda únicamente titular y últimos cuatro dígitos; no se guarda CVV ni número completo. Esta versión académica no procesa cobros reales ni verifica automáticamente los pagos: quedan pendientes de verificación, por lo que para producción se necesita integrar una pasarela de pago oficial.


### Métodos de pago del checkout
El carrito ofrece efectivo contra entrega, tarjeta (demo académica sin cobro real), Yape/Plin y transferencia bancaria. El efectivo se registra como “Pago contra entrega”; la web no procesa cobros reales ni confirma pagos electrónicos automáticamente.
