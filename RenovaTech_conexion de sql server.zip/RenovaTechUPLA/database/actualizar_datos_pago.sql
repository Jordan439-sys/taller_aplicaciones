/* Ejecutar una sola vez sobre la base RenovaTech existente. No elimina datos. */
IF COL_LENGTH('dbo.Pedido','TitularPago') IS NULL ALTER TABLE dbo.Pedido ADD TitularPago NVARCHAR(100) NULL;
IF COL_LENGTH('dbo.Pedido','Ultimos4Tarjeta') IS NULL ALTER TABLE dbo.Pedido ADD Ultimos4Tarjeta CHAR(4) NULL;
IF COL_LENGTH('dbo.Pedido','TelefonoPago') IS NULL ALTER TABLE dbo.Pedido ADD TelefonoPago VARCHAR(9) NULL;
IF COL_LENGTH('dbo.Pedido','BancoPago') IS NULL ALTER TABLE dbo.Pedido ADD BancoPago NVARCHAR(50) NULL;
IF COL_LENGTH('dbo.Pedido','ReferenciaPago') IS NULL ALTER TABLE dbo.Pedido ADD ReferenciaPago NVARCHAR(100) NULL;
IF COL_LENGTH('dbo.Pedido','EstadoPago') IS NULL ALTER TABLE dbo.Pedido ADD EstadoPago NVARCHAR(30) NOT NULL CONSTRAINT DF_Pedido_EstadoPago DEFAULT (N'Pendiente de verificación');
GO
