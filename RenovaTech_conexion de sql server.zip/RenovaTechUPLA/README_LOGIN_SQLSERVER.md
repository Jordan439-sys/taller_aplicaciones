# RenovaTech - Login conectado a SQL Server

Se reemplazó el login de demostración (`sessionStorage` con contraseñas en JavaScript)
por autenticación real contra la base de datos `RenovaTech`.

## 1. Base de datos

Ejecuta primero:

`modelo fisico RENOVATECH(1).sql`

en SQL Server. El script crea la base `RenovaTech` y las cuentas:

- Administrador: `admin` / `admin123`
- Comprador: `comprador` / `comprador123`

## 2. Configurar la conexión

Archivo:

`src/main/java/com/upla/renovatech/config/DatabaseConnection.java`

Por defecto usa:

- servidor: `localhost:1433`
- base de datos: `RenovaTech`
- usuario: `sa`
- contraseña: `TU_PASSWORD_SQLSERVER`

Lo recomendable es usar variables de entorno:

- `RENOVATECH_DB_URL`
- `RENOVATECH_DB_USER`
- `RENOVATECH_DB_PASSWORD`

Si SQL Server está en otra instancia/puerto, cambia `RENOVATECH_DB_URL`.

Ejemplo:

`jdbc:sqlserver://localhost:1433;databaseName=RenovaTech;encrypt=false;trustServerCertificate=true`

## 3. Cómo funciona el login

1. `login.jsp` envía usuario, contraseña y rol mediante POST a `/login`.
2. `LoginServlet` consulta `dbo.Usuario` con `PreparedStatement`.
3. La contraseña se convierte a SHA-256 usando UTF-16LE para coincidir con `HASHBYTES('SHA2_256', N'...')` del SQL.
4. Se valida también el rol y `Activo = 1`.
5. Se crea una `HttpSession` en el servidor.
6. `AuthFilter` protege las páginas según el rol.
7. `/logout` destruye la sesión.

La contraseña ya no está almacenada en `auth.js`.

## 4. Credenciales de SQL Server

No subas a Git la contraseña real. Para desarrollo puedes colocarla temporalmente
en `DatabaseConnection.java`; para producción usa variables de entorno.

## 5. Dependencia agregada

Se agregó el driver oficial JDBC de Microsoft SQL Server:

`com.microsoft.sqlserver:mssql-jdbc:12.8.1.jre11`

El proyecto usa Java 17, por lo que este driver es compatible.

## Integración de productos, compras y pedidos con SQL Server

Esta versión incluye los endpoints del servidor:

- `GET /api/productos`: consulta catálogo, precio y stock directamente desde `dbo.Producto` y `dbo.Categoria`.
- `POST /api/compra`: recibe los artículos del carrito, valida el cliente autenticado y registra la compra usando `dbo.usp_AgregarAlCarrito` y `dbo.usp_FinalizarCompra`. El procedimiento de compra guarda `Pedido` y `DetallePedido`, descuenta el stock y vacía el carrito dentro de una transacción.
- `GET /api/pedidos`: obtiene el historial desde `dbo.vw_PedidosDetalle`; los clientes solo ven sus compras y el administrador puede ver todos los pedidos.

### Requisitos SQL

Ejecuta el script completo `database/renovatech_primera_instalacion.sql` en la base de datos de RenovaTech. Debe contener las tablas `Usuario`, `Producto`, `Categoria`, `MetodoPago`, `Pedido`, `DetallePedido`, `ItemCarrito`, la vista `vw_PedidosDetalle` y los procedimientos `usp_AgregarAlCarrito` y `usp_FinalizarCompra`.

Configura `RENOVATECH_DB_URL`, `RENOVATECH_DB_USER` y `RENOVATECH_DB_PASSWORD` en el entorno donde se ejecuta Tomcat. Ejemplo de URL: `jdbc:sqlserver://localhost:1433;databaseName=RenovaTech;encrypt=false;trustServerCertificate=true`.

Tras cambiar código Java, realiza Clean and Build y vuelve a desplegar el WAR en Tomcat. No basta con actualizar solo los archivos JSP/JavaScript si el servidor está ejecutando una compilación anterior.

Nota: el catálogo web nuevo y la finalización del pedido usan SQL Server como fuente de verdad. Los artículos del carrito se envían al servidor al confirmar la compra; el stock y el precio final se validan con la base de datos, no con el valor mostrado en el navegador.
