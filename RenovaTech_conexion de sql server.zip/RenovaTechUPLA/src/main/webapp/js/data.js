// ============================================================
// RenovaTech - Datos de ejemplo y utilidades de inventario
// Simula un backend usando localStorage del navegador, para que
// Registrar, Editar y Eliminar realmente cambien el catálogo
// mientras navegas entre las páginas de la aplicación.
// ============================================================

const RENOVA_STORAGE_KEY = "renovatech_productos";

const RENOVA_PRODUCTOS_DEFECTO = 
[
    {
        "codigo": "P001",
        "imagen": "img/productos/P001.svg",
        "nombre": "Laptop Lenovo",
        "categoria": "Computadoras",
        "precio": 2500.0,
        "stock": 10,
        "estado": "Disponible"
    },
    {
        "codigo": "P002",
        "imagen": "img/productos/P002.svg",
        "nombre": "Mouse Logitech",
        "categoria": "Accesorios",
        "precio": 80.0,
        "stock": 25,
        "estado": "Disponible"
    },
    {
        "codigo": "P003",
        "imagen": "img/productos/P003.svg",
        "nombre": "Teclado Redragon",
        "categoria": "Accesorios",
        "precio": 150.0,
        "stock": 0,
        "estado": "Agotado"
    },
    {
        "codigo": "P004",
        "imagen": "img/productos/P004.svg",
        "nombre": "Mochila para laptop",
        "categoria": "Accesorios",
        "precio": 141.11,
        "stock": 0,
        "estado": "Agotado"
    },
    {
        "codigo": "P005",
        "imagen": "img/productos/P005.svg",
        "nombre": "Webcam Logitech C920",
        "categoria": "Accesorios",
        "precio": 102.25,
        "stock": 0,
        "estado": "Agotado"
    },
    {
        "codigo": "P006",
        "imagen": "img/productos/P006.svg",
        "nombre": "Hub USB-C 7 en 1",
        "categoria": "Accesorios",
        "precio": 113.33,
        "stock": 2,
        "estado": "Disponible"
    },
    {
        "codigo": "P007",
        "imagen": "img/productos/P007.svg",
        "nombre": "Laptop Asus Vivobook",
        "categoria": "Computadoras",
        "precio": 2677.83,
        "stock": 4,
        "estado": "Disponible"
    },
    {
        "codigo": "P008",
        "imagen": "img/productos/P008.svg",
        "nombre": "Impresora Canon Pixma",
        "categoria": "Impresoras",
        "precio": 718.04,
        "stock": 6,
        "estado": "Disponible"
    },
    {
        "codigo": "P009",
        "imagen": "img/productos/P009.svg",
        "nombre": "Impresora HP LaserJet",
        "categoria": "Impresoras",
        "precio": 704.03,
        "stock": 3,
        "estado": "Disponible"
    },
    {
        "codigo": "P010",
        "imagen": "img/productos/P010.svg",
        "nombre": "Laptop HP Pavilion",
        "categoria": "Computadoras",
        "precio": 2863.4,
        "stock": 8,
        "estado": "Disponible"
    },
    {
        "codigo": "P011",
        "imagen": "img/productos/P011.svg",
        "nombre": "Impresora Epson L3250",
        "categoria": "Impresoras",
        "precio": 412.85,
        "stock": 5,
        "estado": "Disponible"
    },
    {
        "codigo": "P012",
        "imagen": "img/productos/P012.svg",
        "nombre": "Monitor LG 24''",
        "categoria": "Monitores",
        "precio": 467.83,
        "stock": 7,
        "estado": "Disponible"
    },
    {
        "codigo": "P013",
        "imagen": "img/productos/P013.svg",
        "nombre": "Access Point Ubiquiti",
        "categoria": "Redes",
        "precio": 376.64,
        "stock": 9,
        "estado": "Disponible"
    },
    {
        "codigo": "P014",
        "imagen": "img/productos/P014.svg",
        "nombre": "Mini PC Intel NUC",
        "categoria": "Computadoras",
        "precio": 2399.24,
        "stock": 4,
        "estado": "Disponible"
    },
    {
        "codigo": "P015",
        "imagen": "img/productos/P015.svg",
        "nombre": "Audifonos JBL",
        "categoria": "Accesorios",
        "precio": 176.73,
        "stock": 6,
        "estado": "Disponible"
    },
    {
        "codigo": "P016",
        "imagen": "img/productos/P016.svg",
        "nombre": "Monitor AOC 21.5''",
        "categoria": "Monitores",
        "precio": 613.15,
        "stock": 3,
        "estado": "Disponible"
    },
    {
        "codigo": "P017",
        "imagen": "img/productos/P017.svg",
        "nombre": "Router TP-Link AX1800",
        "categoria": "Redes",
        "precio": 272.75,
        "stock": 5,
        "estado": "Disponible"
    },
    {
        "codigo": "P018",
        "imagen": "img/productos/P018.svg",
        "nombre": "Monitor Samsung 27''",
        "categoria": "Monitores",
        "precio": 547.66,
        "stock": 2,
        "estado": "Disponible"
    },
    {
        "codigo": "P019",
        "imagen": "img/productos/P019.svg",
        "nombre": "Cable de red Cat6 (caja)",
        "categoria": "Redes",
        "precio": 144.11,
        "stock": 8,
        "estado": "Disponible"
    },
    {
        "codigo": "P020",
        "imagen": "img/productos/P020.svg",
        "nombre": "Repetidor Wifi TP-Link",
        "categoria": "Redes",
        "precio": 165.89,
        "stock": 4,
        "estado": "Disponible"
    }
];

function renovaGetProductos() {
    const raw = localStorage.getItem(RENOVA_STORAGE_KEY);
    if (!raw) {
        renovaSetProductos(RENOVA_PRODUCTOS_DEFECTO);
        return JSON.parse(JSON.stringify(RENOVA_PRODUCTOS_DEFECTO));
    }
    try {
        return JSON.parse(raw).map(renovaConImagen);
    } catch (e) {
        renovaSetProductos(RENOVA_PRODUCTOS_DEFECTO);
        return JSON.parse(JSON.stringify(RENOVA_PRODUCTOS_DEFECTO));
    }
}

function renovaSetProductos(lista) {
    localStorage.setItem(RENOVA_STORAGE_KEY, JSON.stringify(lista));
}

function renovaResetProductos() {
    renovaSetProductos(RENOVA_PRODUCTOS_DEFECTO);
    // también se borran los pedidos y se vacían los carritos, porque dependen del stock
    localStorage.removeItem("renovatech_pedidos");
    Object.keys(localStorage).filter(function (k) { return k.indexOf("renovatech_carrito_") === 0; })
        .forEach(function (k) { localStorage.removeItem(k); });
}

function renovaBuscarPorCodigo(codigo) {
    return renovaGetProductos().find(p => p.codigo.toLowerCase() === String(codigo).toLowerCase());
}

function renovaExisteCodigo(codigo) {
    return !!renovaBuscarPorCodigo(codigo);
}

function renovaAgregarProducto(p) {
    const lista = renovaGetProductos();
    p.estado = p.stock > 0 ? "Disponible" : "Agotado";
    lista.push(p);
    renovaSetProductos(lista);
}

function renovaActualizarProducto(codigoOriginal, datos) {
    const lista = renovaGetProductos();
    const idx = lista.findIndex(p => p.codigo === codigoOriginal);
    if (idx === -1) return false;
    datos.estado = datos.stock > 0 ? "Disponible" : "Agotado";
    lista[idx] = datos;
    renovaSetProductos(lista);
    return true;
}

function renovaEliminarProducto(codigo) {
    const lista = renovaGetProductos().filter(p => p.codigo !== codigo);
    renovaSetProductos(lista);
}

function renovaEstadisticas() {
    const lista = renovaGetProductos();
    const total = lista.length;
    const disponibles = lista.filter(p => p.stock > 0).length;
    const agotados = total - disponibles;
    const valorInventario = lista.reduce((acc, p) => acc + p.precio * p.stock, 0);
    const stockTotal = lista.reduce((acc, p) => acc + p.stock, 0);
    const disponibilidad = total > 0 ? Math.round((disponibles / total) * 100) : 0;
    return { total, disponibles, agotados, valorInventario, stockTotal, disponibilidad };
}

function renovaFormatoMoneda(valor) {
    return "S/ " + Number(valor).toLocaleString("es-PE", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function renovaFechaActual() {
    const hoy = new Date();
    const texto = hoy.toLocaleDateString("es-PE", { day: "numeric", month: "long", year: "numeric" });
    return texto.charAt(0).toUpperCase() + texto.slice(1);
}

function renovaBadge(estado) {
    const clase = estado === "Disponible" ? "badge-disponible" : "badge-agotado";
    return '<span class="badge ' + clase + '">' + estado + '</span>';
}

function renovaCategoriasUnicas() {
    const lista = renovaGetProductos();
    return [...new Set(lista.map(p => p.categoria))].sort();
}


// ---------- Imágenes ----------
const RENOVA_IMAGEN_GENERICA = "img/productos/generico.svg";

// Garantiza que cada producto tenga imagen (los guardados antes no la traían).
function renovaConImagen(p) {
    if (!p.imagen) {
        const d = RENOVA_PRODUCTOS_DEFECTO.find(x => x.codigo === p.codigo);
        p.imagen = d ? d.imagen : RENOVA_IMAGEN_GENERICA;
    }
    return p;
}

// Lee un archivo de imagen, lo reduce a 480 px y lo devuelve como texto (data URL).
function renovaLeerImagen(file, cb) {
    const reader = new FileReader();
    reader.onerror = function () { cb(null); };
    reader.onload = function (e) {
        const img = new Image();
        img.onerror = function () { cb(null); };
        img.onload = function () {
            const k = Math.min(1, 480 / Math.max(img.width, img.height));
            const c = document.createElement("canvas");
            c.width = Math.round(img.width * k);
            c.height = Math.round(img.height * k);
            c.getContext("2d").drawImage(img, 0, 0, c.width, c.height);
            cb(c.toDataURL("image/jpeg", 0.82));
        };
        img.src = e.target.result;
    };
    reader.readAsDataURL(file);
}

// ---------- Tablas ----------
function renovaEsc(t) {
    return String(t).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}

function renovaThumb(p, clase) {
    return '<img class="' + (clase || "thumb") + '" src="' + renovaEsc(p.imagen || RENOVA_IMAGEN_GENERICA) + '" alt="' + renovaEsc(p.nombre) +
        '" loading="lazy" onerror="this.onerror=null;this.src=\'' + RENOVA_IMAGEN_GENERICA + '\'">';
}

const RENOVA_ICONO_CARRITO = '<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"/></svg>';

// modo: "enlaces" (Editar / Eliminar abren otra página), "modal" (Eliminar abre la confirmación)
// o "ninguno". El administrador ve Editar/Eliminar; el comprador ve el botón Agregar al carrito.
function renovaFilaProducto(p, modo) {
    const cod = encodeURIComponent(p.codigo);
    const s = renovaSesion();
    let acciones = "";
    if (s && modo !== "ninguno") {
        if (s.rol === "administrador") {
            const eliminar = modo === "modal"
                ? '<a class="action-delete" href="#" onclick="abrirModal(\'' + String(p.codigo).replace(/'/g, "\\'") + '\');return false;">Eliminar</a>'
                : '<a class="action-delete" href="eliminar.jsp?codigo=' + cod + '">Eliminar</a>';
            acciones = '<td><a class="action-edit" href="editar.jsp?codigo=' + cod + '">Editar</a>' + eliminar + '</td>';
        } else if (s.rol === "comprador") {
            acciones = '<td>' + (p.stock > 0
                ? '<button type="button" class="btn-add" data-cod="' + renovaEsc(p.codigo) + '" onclick="renovaClickAgregar(this)">' + RENOVA_ICONO_CARRITO + ' Agregar</button>'
                : '<span class="text-xs text-gray-400">Agotado</span>') + '</td>';
        }
    }
    return '<tr>' +
        '<td>' + renovaThumb(p) + '</td>' +
        '<td class="text-gray-400">' + renovaEsc(p.codigo) + '</td>' +
        '<td class="font-semibold text-gray-800">' + renovaEsc(p.nombre) + '</td>' +
        '<td>' + renovaEsc(p.categoria) + '</td>' +
        '<td>' + Number(p.precio).toFixed(2) + '</td>' +
        '<td>' + p.stock + '</td>' +
        '<td>' + renovaBadge(p.estado) + '</td>' + acciones + '</tr>';
}

// Número de columnas de la tabla (para las filas vacías).
function renovaColumnas(modo) {
    return (renovaSesion() && modo !== "ninguno") ? 8 : 7;
}

// ---------- Paginador numerado ----------
function renovaRenderPaginador(idContenedor, pagina, total, alCambiar) {
    const el = document.getElementById(idContenedor);
    if (!el) { return; }
    const nums = [];
    for (let i = 1; i <= total; i++) {
        if (i === 1 || i === total || Math.abs(i - pagina) <= 1) { nums.push(i); }
        else if (nums[nums.length - 1] !== "...") { nums.push("..."); }
    }
    let h = '<button class="pag-btn" data-p="' + (pagina - 1) + '"' + (pagina <= 1 ? " disabled" : "") + ' aria-label="Anterior">&lsaquo;</button>';
    nums.forEach(function (n) {
        h += n === "..." ? '<span class="pag-dots">&hellip;</span>'
            : '<button class="pag-btn' + (n === pagina ? " active" : "") + '" data-p="' + n + '">' + n + '</button>';
    });
    h += '<button class="pag-btn" data-p="' + (pagina + 1) + '"' + (pagina >= total ? " disabled" : "") + ' aria-label="Siguiente">&rsaquo;</button>';
    el.innerHTML = h;
    el.querySelectorAll("button").forEach(function (b) {
        b.onclick = function () {
            const n = parseInt(b.getAttribute("data-p"), 10);
            if (n >= 1 && n <= total && n !== pagina) { alCambiar(n); }
        };
    });
}
