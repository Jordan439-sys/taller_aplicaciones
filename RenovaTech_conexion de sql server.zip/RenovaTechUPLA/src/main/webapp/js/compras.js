// ============================================================
// RenovaTech - Carrito y pedidos del comprador
// El carrito se guarda por usuario en localStorage. Al finalizar la
// compra se descuenta el stock del catálogo y se guarda el pedido.
// ============================================================

const RENOVA_PEDIDOS_KEY = "renovatech_pedidos";
const RENOVA_CARRITO_PREFIJO = "renovatech_carrito_";

// ---------- Carrito ----------
function renovaClaveCarrito() {
    const s = renovaSesion();
    return s ? RENOVA_CARRITO_PREFIJO + s.usuario.toLowerCase() : null;
}

function renovaGetCarrito() {
    const k = renovaClaveCarrito();
    if (!k) { return []; }
    try {
        const c = JSON.parse(localStorage.getItem(k));
        return Array.isArray(c) ? c : [];
    } catch (e) {
        return [];
    }
}

function renovaSetCarrito(c) {
    const k = renovaClaveCarrito();
    if (k) { localStorage.setItem(k, JSON.stringify(c)); }
    renovaActualizarBadgeCarrito();
}

function renovaUnidadesCarrito() {
    return renovaGetCarrito().reduce(function (a, i) { return a + i.cantidad; }, 0);
}

function renovaActualizarBadgeCarrito() {
    const el = document.getElementById("cartBadge");
    if (!el) { return; }
    const n = renovaUnidadesCarrito();
    el.textContent = n;
    el.style.display = n > 0 ? "inline-block" : "none";
}

function renovaAgregarAlCarrito(codigo, cantidad) {
    cantidad = cantidad || 1;
    const p = renovaBuscarPorCodigo(codigo);
    if (!p) { return { ok: false, mensaje: "El producto ya no existe." }; }
    if (p.stock <= 0) { return { ok: false, mensaje: p.nombre + " está agotado." }; }
    const c = renovaGetCarrito();
    const it = c.find(function (i) { return i.codigo === p.codigo; });
    const nueva = (it ? it.cantidad : 0) + cantidad;
    if (nueva > p.stock) {
        return { ok: false, mensaje: "Solo hay " + p.stock + " unidad(es) de " + p.nombre + "." };
    }
    if (it) { it.cantidad = nueva; } else { c.push({ codigo: p.codigo, cantidad: cantidad }); }
    renovaSetCarrito(c);
    return { ok: true, mensaje: p.nombre + " agregado al carrito." };
}

function renovaCambiarCantidad(codigo, cantidad) {
    const p = renovaBuscarPorCodigo(codigo);
    let c = renovaGetCarrito();
    if (cantidad <= 0 || !p) {
        c = c.filter(function (i) { return i.codigo !== codigo; });
    } else {
        const it = c.find(function (i) { return i.codigo === codigo; });
        if (it) { it.cantidad = Math.min(cantidad, p.stock); }
    }
    renovaSetCarrito(c);
}

function renovaQuitarDelCarrito(codigo) { renovaCambiarCantidad(codigo, 0); }

// Devuelve las líneas del carrito con datos actuales. Quita productos que ya no
// existen o se agotaron y ajusta las cantidades al stock (con avisos).
function renovaDetalleCarrito() {
    const avisos = [];
    const lineas = [];
    const limpio = [];
    renovaGetCarrito().forEach(function (it) {
        const p = renovaBuscarPorCodigo(it.codigo);
        if (!p) { avisos.push("Un producto del carrito ya no está en el catálogo y se quitó."); return; }
        if (p.stock <= 0) { avisos.push(p.nombre + " se agotó y se quitó del carrito."); return; }
        let cant = it.cantidad;
        if (cant > p.stock) {
            cant = p.stock;
            avisos.push("La cantidad de " + p.nombre + " se ajustó a " + p.stock + " por falta de stock.");
        }
        limpio.push({ codigo: p.codigo, cantidad: cant });
        lineas.push({ producto: p, cantidad: cant, subtotal: Math.round(p.precio * cant * 100) / 100 });
    });
    if (avisos.length) { renovaSetCarrito(limpio); }
    const total = Math.round(lineas.reduce(function (a, l) { return a + l.subtotal; }, 0) * 100) / 100;
    const unidades = lineas.reduce(function (a, l) { return a + l.cantidad; }, 0);
    return { lineas: lineas, total: total, unidades: unidades, avisos: avisos };
}

// ---------- Pedidos ----------
function renovaGetPedidos() {
    try {
        const p = JSON.parse(localStorage.getItem(RENOVA_PEDIDOS_KEY));
        return Array.isArray(p) ? p : [];
    } catch (e) {
        return [];
    }
}

// Valida el stock, lo descuenta, guarda el pedido y vacía el carrito.
async function renovaFinalizarCompra(pago) {
    const s = renovaSesion();
    if (!s || s.rol !== "comprador") return { ok: false, mensaje: "Debes iniciar sesión como comprador." };
    const carrito = renovaGetCarrito();
    if (!carrito.length) return { ok: false, mensaje: "Tu carrito está vacío." };
    const datos = new URLSearchParams();
    datos.set("metodo", pago.metodo || "");
    ["titular", "ultimos4", "telefono", "banco", "referencia"].forEach(function (k) { if (pago[k]) datos.set(k, pago[k]); });
    carrito.forEach(function (it) { datos.append("codigo", it.codigo); datos.append("cantidad", String(it.cantidad)); });
    try {
        const resp = await fetch("api/compra", { method: "POST", headers: { "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8" }, body: datos.toString() });
        const r = await resp.json();
        if (!resp.ok || !r.ok) return { ok: false, mensaje: r.error || "No se pudo registrar la compra en SQL Server." };
        renovaSetCarrito([]);
        localStorage.removeItem(RENOVA_PEDIDOS_KEY);
        // Recargar el catálogo desde el backend para reflejar el stock actualizado.
        try {
            const pr = await fetch("api/productos", { cache: "no-store" });
            if (pr.ok) {
                const arr = await pr.json();
                renovaSetProductos(arr.map(x => ({ codigo:x.codigo, nombre:x.nombre, categoria:x.categoria, precio:Number(x.precio), stock:Number(x.stock), estado:x.estado, imagen:x.imagen })));
            }
        } catch (e) {}
        return { ok: true, pedido: { id: r.pedido } };
    } catch (e) { return { ok: false, mensaje: "No se pudo contactar con el servidor. Revisa Tomcat y SQL Server." }; }
}

async function renovaCargarPedidosSQL() {
    const resp = await fetch("api/pedidos", { cache: "no-store" });
    const data = await resp.json();
    if (!resp.ok) throw new Error(data.error || "No se pudo cargar el historial.");
    return data;
}

function renovaFechaHora(iso) {
    return new Date(iso).toLocaleString("es-PE", { day: "numeric", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit" });
}

// ---------- Avisos en pantalla ----------
function renovaToast(mensaje, ok, enlaceTexto, enlaceHref) {
    let cont = document.getElementById("toastWrap");
    if (!cont) {
        cont = document.createElement("div");
        cont.id = "toastWrap";
        cont.className = "toast-wrap";
        document.body.appendChild(cont);
    }
    const t = document.createElement("div");
    t.className = "toast" + (ok ? "" : " error");
    const span = document.createElement("span");
    span.textContent = mensaje;
    t.appendChild(span);
    if (enlaceTexto) {
        const a = document.createElement("a");
        a.href = enlaceHref;
        a.textContent = enlaceTexto;
        t.appendChild(a);
    }
    cont.appendChild(t);
    setTimeout(function () { t.remove(); }, 3500);
}

// Botón "Agregar" de las tablas del catálogo.
function renovaClickAgregar(btn) {
    const r = renovaAgregarAlCarrito(btn.getAttribute("data-cod"), 1);
    if (r.ok) { renovaToast(r.mensaje, true, "Ver carrito", "carrito.jsp"); } else { renovaToast(r.mensaje, false); }
}
