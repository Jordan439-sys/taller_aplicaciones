// RenovaTech - autenticación conectada al servidor.
// Las credenciales se validan en SQL Server mediante LoginServlet.
// sessionStorage/cookies solo sirven para actualizar la interfaz; la seguridad real
// de las páginas la aplica AuthFilter usando HttpSession.

const RENOVA_SESION_KEY = "renovatech_sesion";
const RENOVA_COMPRADORES_KEY = "renovatech_compradores";

function renovaGetCompradores() {
    try {
        const c = JSON.parse(localStorage.getItem(RENOVA_COMPRADORES_KEY));
        return Array.isArray(c) ? c : [];
    } catch (e) {
        return [];
    }
}

function renovaTodosLosUsuarios() {
    return renovaGetCompradores();
}

// Se mantiene para la pantalla de registro existente.
// Nota: las cuentas creadas aquí siguen siendo locales hasta conectar registro.jsp
// con un servlet de registro.
function renovaRegistrarComprador(d) {
    const nombre = String(d.nombre || "").trim().replace(/\s+/g, " ");
    const correo = String(d.correo || "").trim();
    const usuario = String(d.usuario || "").trim();
    const clave = String(d.clave || "");
    if (nombre.length < 3) { return { ok: false, campo: "nombre", mensaje: "Escribe tu nombre completo." }; }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(correo)) { return { ok: false, campo: "correo", mensaje: "Escribe un correo electrónico válido." }; }
    if (!/^[A-Za-z0-9_.]{4,20}$/.test(usuario)) {
        return { ok: false, campo: "usuario", mensaje: "El usuario debe tener de 4 a 20 caracteres (letras, números, punto o guion bajo)." };
    }
    if (clave.length < 6) { return { ok: false, campo: "clave", mensaje: "La contraseña debe tener al menos 6 caracteres." }; }
    if (clave !== String(d.clave2 || "")) { return { ok: false, campo: "clave2", mensaje: "Las contraseñas no coinciden." }; }
    if (renovaTodosLosUsuarios().some(u => u.usuario.toLowerCase() === usuario.toLowerCase())) {
        return { ok: false, campo: "usuario", mensaje: "Ese usuario ya está en uso. Elige otro." };
    }
    const lista = renovaGetCompradores();
    lista.push({ usuario, clave, correo, nombre: nombre.toUpperCase(), rol: "cliente", creado: new Date().toISOString() });
    localStorage.setItem(RENOVA_COMPRADORES_KEY, JSON.stringify(lista));
    return { ok: true, usuario };
}

function renovaSesion() {
    try {
        const actual = JSON.parse(sessionStorage.getItem(RENOVA_SESION_KEY));
        if (actual) return actual;
    } catch (e) {}

    const cookies = Object.fromEntries(document.cookie.split(";").map(c => {
        const i = c.indexOf("=");
        return [
            i >= 0 ? c.slice(0, i).trim() : c.trim(),
            i >= 0 ? decodeURIComponent(c.slice(i + 1)) : ""
        ];
    }));

    if (cookies.renova_user && cookies.renova_rol) {
        const sesion = {
            usuario: cookies.renova_user,
            nombre: cookies.renova_name || cookies.renova_user,
            rol: cookies.renova_rol
        };
        sessionStorage.setItem(RENOVA_SESION_KEY, JSON.stringify(sesion));
        return sesion;
    }

    return null;
}

function renovaEsAdmin() {
    const s = renovaSesion();
    return !!s && s.rol === "administrador";
}

// El login real se hace mediante POST del formulario a /login.
function renovaIniciarSesion() {
    return { ok: false, mensaje: "El inicio de sesión se realiza en el servidor." };
}

function renovaCerrarSesion() {
    sessionStorage.removeItem(RENOVA_SESION_KEY);
    window.location.href = "logout";
}

function renovaProtegerPagina(rolesPermitidos) {
    const s = renovaSesion();
    if (!s) {
        window.location.replace("login.jsp");
        return null;
    }
    if (rolesPermitidos && rolesPermitidos.length && rolesPermitidos.indexOf(s.rol) === -1) {
        window.location.replace("index.jsp");
        return null;
    }
    return s;
}

function renovaAplicarRol() {
    const s = renovaSesion();
    if (!s) return;

    const partes = s.nombre.split(" ");
    const iniciales = (partes[0][0] + (partes[1] ? partes[1][0] : "")).toUpperCase();

    const set = function (id, txt) {
        const el = document.getElementById(id);
        if (el) el.textContent = txt;
    };

    set("userNombre", s.nombre);
    set("userRol", s.rol === "administrador" ? "Administrador" : "Cliente");
    set("userIniciales", iniciales);

    if (typeof renovaActualizarBadgeCarrito === "function") {
        renovaActualizarBadgeCarrito();
    }

    document.querySelectorAll("[data-solo]").forEach(function (el) {
        if (el.getAttribute("data-solo") !== s.rol) {
            el.style.display = "none";
        }
    });
}
