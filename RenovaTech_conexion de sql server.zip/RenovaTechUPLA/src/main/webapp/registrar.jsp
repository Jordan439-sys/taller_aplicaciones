<%@ page contentType="text/html;charset=UTF-8" language="java" isELIgnored="true" %>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registrar producto - RenovaTech</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="css/estilos.css">
    <link rel="stylesheet" href="css/catalogo.css">
    <script src="js/data.js"></script>
    <script src="js/auth.js"></script>
    <script src="js/compras.js"></script>
    <script>renovaProtegerPagina(["administrador"]);</script>
</head>
<body class="bg-[#f8fafc] min-h-screen">
    <div class="flex min-h-screen">
        <aside class="sidebar w-64 flex-shrink-0 flex flex-col py-5 px-3 text-sm">
            <div class="flex items-center gap-2 px-3 pb-5 mb-2 border-b border-white/10">
                <div class="w-9 h-9 rounded-lg bg-white/10 flex items-center justify-center text-white"><svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16Z"/><polyline points="3.29 7 12 12 20.71 7"/><line x1="12" y1="22" x2="12" y2="12"/></svg></div>
                <div>
                    <div class="text-white font-bold text-[15px] leading-tight">RenovaTech</div>
                    <div class="text-slate-400 text-[11px] leading-tight">Gestión de inventario</div>
                </div>
            </div>
            <nav class="flex-1 flex flex-col gap-0.5">
                <a href="index.jsp" class="nav-link"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/></svg><span>Inicio</span></a>
                <div class="nav-section">PRODUCTOS</div>
                <a href="registrar.jsp" class="nav-link active" data-solo="administrador"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg><span>Registrar producto</span></a>
                <a href="listar.jsp" class="nav-link"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/><line x1="3" y1="6" x2="3.01" y2="6"/><line x1="3" y1="12" x2="3.01" y2="12"/><line x1="3" y1="18" x2="3.01" y2="18"/></svg><span>Listar productos</span></a>
                <a href="buscar.jsp" class="nav-link"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="7"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg><span>Buscar producto</span></a>
                <a href="editar.jsp" class="nav-link" data-solo="administrador"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.12 2.12 0 0 1 3 3L12 15l-4 1 1-4Z"/></svg><span>Editar producto</span></a>
                <a href="eliminar.jsp" class="nav-link" data-solo="administrador"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6"/><path d="M14 11v6"/><path d="M9 6V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2"/></svg><span>Eliminar producto</span></a>
                <div class="nav-section" data-solo="comprador">COMPRAS</div>
                <a href="carrito.jsp" class="nav-link" data-solo="comprador"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"/></svg><span>Carrito</span><span id="cartBadge" class="cart-badge" style="display:none">0</span></a>
                <a href="pedidos.jsp" class="nav-link" data-solo="comprador"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 5H7a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2h-2"/><rect x="9" y="3" width="6" height="4" rx="1"/><line x1="9" y1="12" x2="15" y2="12"/><line x1="9" y1="16" x2="15" y2="16"/></svg><span>Mis compras</span></a>
                <div class="nav-section">REPORTES</div>
                <a href="disponibles.jsp" class="nav-link"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 8v8a2 2 0 0 1-1 1.73l-6 3.46a2 2 0 0 1-2 0l-6-3.46A2 2 0 0 1 3 16V8"/><path d="M3.27 6.96 12 12l8.73-5.04"/><path d="M12 22V12"/><path d="m7 4.5 10 5.77"/></svg><span>Productos disponibles</span></a>
                <a href="resumen.jsp" class="nav-link" data-solo="administrador"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/></svg><span>Resumen de productos</span></a>
                <a href="pedidos.jsp" class="nav-link" data-solo="administrador"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 5H7a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2h-2"/><rect x="9" y="3" width="6" height="4" rx="1"/><line x1="9" y1="12" x2="15" y2="12"/><line x1="9" y1="16" x2="15" y2="16"/></svg><span>Pedidos</span></a>
                <div class="my-2"></div>
                <a href="información.jsp" class="nav-link"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg><span>Información</span></a>
            </nav>
            <div class="pt-4 mt-4 border-t border-white/10">
                <div class="px-3 pb-2 text-[10.5px] font-bold tracking-wide text-slate-500">ENTORNO DE DEMOSTRACIÓN</div>
                <a href="login.jsp" class="nav-link" onclick="renovaCerrarSesion()"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg><span>Cerrar sesión</span></a>
            </div>
        </aside>
        <div class="flex-1 flex flex-col">
        <header class="flex items-center justify-between px-8 py-4 bg-white border-b border-gray-200">
            <div class="text-sm text-gray-500">
                <span>RenovaTech</span>
                <span class="mx-1.5">&rsaquo;</span>
                <span class="text-gray-800 font-medium">Registrar producto</span>
            </div>
            <div class="flex items-center gap-4">
                <span id="fechaActual" class="text-sm text-gray-400"></span>
                <div class="h-6 w-px bg-gray-200"></div>
                <div class="flex items-center gap-2">
                    <div id="userIniciales" class="avatar-circle">JV</div>
                    <div class="leading-tight">
                        <div id="userNombre" class="text-sm font-semibold text-gray-800">JORDAN VERA</div>
                        <div id="userRol" class="text-xs text-gray-400">Administrador</div>
                    </div>
                </div>
            </div>
        </header>
            <main class="flex-1 px-8 py-8">

                <h1 class="text-2xl font-bold text-gray-900">Registrar producto</h1>
                <p class="text-sm text-gray-500 mt-1 mb-6">Añade un nuevo producto al catálogo de inventario.</p>

                <div class="grid grid-cols-1 lg:grid-cols-[2fr_1fr] gap-6">
                    <div class="card-white p-7">
                        <h2 class="text-base font-semibold text-gray-900">Datos del producto</h2>
                        <p class="text-sm text-gray-500 mb-5">Los campos con * son obligatorios.</p>

                        <div id="alertDuplicado" class="hidden bg-red-50 border border-red-200 text-red-700 text-sm px-4 py-3 rounded-lg mb-5">
                            Revisa el código antes de guardar. <span id="codigoDuplicado" class="font-semibold"></span> ya está registrado.
                        </div>
                        <div id="alertExito" class="hidden bg-emerald-50 border border-emerald-200 text-emerald-700 text-sm px-4 py-3 rounded-lg mb-5">
                            Producto registrado correctamente.
                        </div>

                        <div class="grid grid-cols-1 sm:grid-cols-2 gap-5">
                            <div>
                                <label class="block text-sm font-semibold text-gray-700 mb-2">Código *</label>
                                <input type="text" id="fCodigo" placeholder="P021" class="w-full px-4 py-3 rounded-lg border border-gray-300 outline-none focus:ring-2 focus:ring-blue-500 font-medium text-gray-800">
                                <p id="hintCodigo" class="text-xs text-gray-400 mt-1">Identificador único del producto.</p>
                            </div>
                            <div>
                                <label class="block text-sm font-semibold text-gray-700 mb-2">Nombre *</label>
                                <input type="text" id="fNombre" placeholder="Nombre del producto" class="w-full px-4 py-3 rounded-lg border border-gray-300 outline-none focus:ring-2 focus:ring-blue-500 font-medium text-gray-800">
                                <p class="text-xs text-gray-400 mt-1">Nombre obligatorio.</p>
                            </div>
                            <div>
                                <label class="block text-sm font-semibold text-gray-700 mb-2">Categoría *</label>
                                <select id="fCategoria" class="w-full px-4 py-3 rounded-lg border border-gray-300 outline-none focus:ring-2 focus:ring-blue-500 font-medium text-gray-800 bg-white"></select>
                                <p class="text-xs text-gray-400 mt-1">Categoría obligatoria.</p>
                            </div>
                            <div>
                                <label class="block text-sm font-semibold text-gray-700 mb-2">Estado *</label>
                                <select id="fEstado" class="w-full px-4 py-3 rounded-lg border border-gray-300 outline-none focus:ring-2 focus:ring-blue-500 font-medium text-gray-800 bg-white">
                                    <option value="Disponible">Disponible</option>
                                    <option value="Agotado">Agotado</option>
                                </select>
                                <p class="text-xs text-gray-400 mt-1">Opciones: Disponible / Agotado.</p>
                            </div>
                            <div>
                                <label class="block text-sm font-semibold text-gray-700 mb-2">Precio *</label>
                                <input type="number" id="fPrecio" min="0" step="0.01" placeholder="S/ 0.00" class="w-full px-4 py-3 rounded-lg border border-gray-300 outline-none focus:ring-2 focus:ring-blue-500 font-medium text-gray-800">
                                <p class="text-xs text-gray-400 mt-1">Valor decimal mayor que 0. Moneda: soles (S/).</p>
                            </div>
                            <div>
                                <label class="block text-sm font-semibold text-gray-700 mb-2">Stock *</label>
                                <input type="number" id="fStock" min="0" step="1" placeholder="0" class="w-full px-4 py-3 rounded-lg border border-gray-300 outline-none focus:ring-2 focus:ring-blue-500 font-medium text-gray-800">
                                <p class="text-xs text-gray-400 mt-1">Número entero mayor o igual que 0.</p>
                            </div>
                            <div class="sm:col-span-2">
                                <label class="block text-sm font-semibold text-gray-700 mb-2">Imagen del producto (opcional)</label>
                                <div class="flex items-center gap-4">
                                    <img id="fPreview" src="img/productos/generico.svg" alt="Vista previa" class="thumb-lg" style="width:120px;height:90px;flex-shrink:0">
                                    <div>
                                        <input type="file" id="fImagen" accept="image/*" class="text-sm text-gray-600">
                                        <p class="text-xs text-gray-400 mt-1">JPG o PNG. Se reduce automáticamente. Si no eliges ninguna, se usa una imagen genérica.</p>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="flex items-center justify-between mt-7">
                            <p class="text-xs text-gray-400">Completa los datos del nuevo producto.</p>
                            <div class="flex gap-3">
                                <button id="btnLimpiar" class="px-5 py-3 border border-gray-300 rounded-xl text-sm font-medium text-gray-600 hover:bg-gray-50">Limpiar</button>
                                <button id="btnGuardar" class="px-5 py-3 btn-primary-upla text-white rounded-xl text-sm font-medium shadow-sm">Guardar producto</button>
                            </div>
                        </div>
                    </div>

                    <div class="card-white p-6 h-fit">
                        <span class="text-xs font-bold text-gray-400 uppercase tracking-wide">Antes de registrar</span>
                        <h3 class="text-base font-semibold text-gray-900 mt-2 mb-3">Antes de registrar</h3>
                        <ul class="space-y-3 text-sm text-gray-600">
                            <li>Usa un código único para identificar el producto y evitar registros duplicados.</li>
                            <li>Selecciona su categoría y completa el precio y las existencias actuales.</li>
                            <li>El stock puede ser 0. Los reportes de disponibles solo incluyen productos con stock mayor que 0.</li>
                        </ul>
                        <a href="#" id="linkEjemplo" class="text-sm text-blue-600 font-medium mt-4 inline-block">Ejemplo de validación visible &rarr;</a>
                    </div>
                </div>

            </main>
        </div>
    </div>

    <script>
        document.getElementById("fechaActual").textContent = "Fecha actual: " + renovaFechaActual();
        renovaAplicarRol();
    </script>
    <script>
        const CATEGORIAS = renovaCategoriasUnicas();
        const selCat = document.getElementById("fCategoria");
        selCat.innerHTML = '<option value="">Selecciona una categoría</option>' +
            CATEGORIAS.map(c => '<option value="' + c + '">' + c + '</option>').join("") +
            '<option value="__nueva__">+ Nueva categoría...</option>';

        document.getElementById("fStock").addEventListener("input", function () {
            const v = parseFloat(this.value) || 0;
            document.getElementById("fEstado").value = v > 0 ? "Disponible" : "Agotado";
        });

        function validarCodigoEnVivo() {
            const codigo = document.getElementById("fCodigo").value.trim();
            const input = document.getElementById("fCodigo");
            const alerta = document.getElementById("alertDuplicado");
            if (codigo && renovaExisteCodigo(codigo)) {
                input.classList.add("border-red-400");
                document.getElementById("hintCodigo").textContent = "Este código ya existe. Utiliza uno único.";
                document.getElementById("hintCodigo").classList.add("text-red-500");
                document.getElementById("codigoDuplicado").textContent = codigo;
                alerta.classList.remove("hidden");
                return false;
            }
            input.classList.remove("border-red-400");
            document.getElementById("hintCodigo").textContent = "Identificador único del producto.";
            document.getElementById("hintCodigo").classList.remove("text-red-500");
            alerta.classList.add("hidden");
            return true;
        }
        document.getElementById("fCodigo").addEventListener("input", validarCodigoEnVivo);

        document.getElementById("linkEjemplo").addEventListener("click", function (e) {
            e.preventDefault();
            document.getElementById("fCodigo").value = "P001";
            validarCodigoEnVivo();
        });

        let imagenNueva = null;
        document.getElementById("fImagen").addEventListener("change", function () {
            const archivo = this.files[0];
            if (!archivo) { return; }
            renovaLeerImagen(archivo, function (data) {
                if (!data) { alert("No se pudo leer la imagen. Prueba con otro archivo."); return; }
                imagenNueva = data;
                document.getElementById("fPreview").src = data;
            });
        });

        document.getElementById("btnLimpiar").addEventListener("click", function () {
            imagenNueva = null;
            document.getElementById("fImagen").value = "";
            document.getElementById("fPreview").src = RENOVA_IMAGEN_GENERICA;
            document.getElementById("fCodigo").value = "";
            document.getElementById("fNombre").value = "";
            selCat.value = "";
            document.getElementById("fEstado").value = "Disponible";
            document.getElementById("fPrecio").value = "";
            document.getElementById("fStock").value = "";
            document.getElementById("alertDuplicado").classList.add("hidden");
            document.getElementById("alertExito").classList.add("hidden");
            document.getElementById("fCodigo").classList.remove("border-red-400");
        });

        document.getElementById("btnGuardar").addEventListener("click", function () {
            const codigo = document.getElementById("fCodigo").value.trim();
            const nombre = document.getElementById("fNombre").value.trim();
            let categoria = selCat.value;
            const estado = document.getElementById("fEstado").value;
            const precio = parseFloat(document.getElementById("fPrecio").value);
            const stock = parseInt(document.getElementById("fStock").value, 10);

            if (categoria === "__nueva__") {
                categoria = prompt("Nombre de la nueva categoría:") || "";
            }

            if (!codigo || !nombre || !categoria || isNaN(precio) || precio <= 0 || isNaN(stock) || stock < 0) {
                alert("Completa todos los campos obligatorios con valores válidos.");
                return;
            }
            if (!validarCodigoEnVivo()) { return; }

            renovaAgregarProducto({ codigo, nombre, categoria, precio, stock, estado, imagen: imagenNueva || RENOVA_IMAGEN_GENERICA });
            document.getElementById("alertExito").classList.remove("hidden");
            document.getElementById("btnLimpiar").click();
        });
    </script>

</body>
</html>
