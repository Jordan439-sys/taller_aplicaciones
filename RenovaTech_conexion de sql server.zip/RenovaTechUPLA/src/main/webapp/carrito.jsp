<%@ page contentType="text/html;charset=UTF-8" language="java" isELIgnored="true" %>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Carrito - RenovaTech</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="css/estilos.css">
    <link rel="stylesheet" href="css/catalogo.css">
    <link rel="stylesheet" href="css/checkout.css">
    <script src="js/data.js"></script>
    <script src="js/auth.js"></script>
    <script src="js/compras.js"></script>
    <script>renovaProtegerPagina(["comprador"]);</script>
</head>
<body class="bg-[#f8fafc] min-h-screen">
    <div class="flex min-h-screen">
        <aside class="sidebar w-64 flex-shrink-0 flex flex-col py-5 px-3 text-sm">
            <div class="flex items-center gap-2 px-3 pb-5 mb-2 border-b border-white/10">
                <div class="w-9 h-9 rounded-lg bg-white/10 flex items-center justify-center text-white"><svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16Z"/><polyline points="3.29 7 12 12 20.71 7"/><line x1="12" y1="22" x2="12" y2="12"/></svg></div>
                <div>
                    <div class="text-white font-bold text-[15px] leading-tight">RenovaTech</div>
                    <div class="text-slate-400 text-[11px] leading-tight">Gestión de inventario</div>
                </div>
            </div>
            <nav class="flex-1 flex flex-col gap-0.5">
                <a href="index.jsp" class="nav-link"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/></svg><span>Inicio</span></a>
                <div class="nav-section">PRODUCTOS</div>
                <a href="registrar.jsp" class="nav-link" data-solo="administrador"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg><span>Registrar producto</span></a>
                <a href="listar.jsp" class="nav-link"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/><line x1="3" y1="6" x2="3.01" y2="6"/><line x1="3" y1="12" x2="3.01" y2="12"/><line x1="3" y1="18" x2="3.01" y2="18"/></svg><span>Listar productos</span></a>
                <a href="buscar.jsp" class="nav-link"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="7"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg><span>Buscar producto</span></a>
                <a href="editar.jsp" class="nav-link" data-solo="administrador"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.12 2.12 0 0 1 3 3L12 15l-4 1 1-4Z"/></svg><span>Editar producto</span></a>
                <a href="eliminar.jsp" class="nav-link" data-solo="administrador"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6"/><path d="M14 11v6"/><path d="M9 6V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2"/></svg><span>Eliminar producto</span></a>
                <div class="nav-section" data-solo="comprador">COMPRAS</div>
                <a href="carrito.jsp" class="nav-link active" data-solo="comprador"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"/></svg><span>Carrito</span><span id="cartBadge" class="cart-badge" style="display:none">0</span></a>
                <a href="pedidos.jsp" class="nav-link" data-solo="comprador"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 5H7a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2h-2"/><rect x="9" y="3" width="6" height="4" rx="1"/><line x1="9" y1="12" x2="15" y2="12"/><line x1="9" y1="16" x2="15" y2="16"/></svg><span>Mis compras</span></a>
                <div class="nav-section">REPORTES</div>
                <a href="disponibles.jsp" class="nav-link"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 8v8a2 2 0 0 1-1 1.73l-6 3.46a2 2 0 0 1-2 0l-6-3.46A2 2 0 0 1 3 16V8"/><path d="M3.27 6.96 12 12l8.73-5.04"/><path d="M12 22V12"/><path d="m7 4.5 10 5.77"/></svg><span>Productos disponibles</span></a>
                <a href="resumen.jsp" class="nav-link" data-solo="administrador"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/></svg><span>Resumen de productos</span></a>
                <a href="pedidos.jsp" class="nav-link" data-solo="administrador"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 5H7a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2h-2"/><rect x="9" y="3" width="6" height="4" rx="1"/><line x1="9" y1="12" x2="15" y2="12"/><line x1="9" y1="16" x2="15" y2="16"/></svg><span>Pedidos</span></a>
                <div class="my-2"></div>
                <a href="información.jsp" class="nav-link"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg><span>Información</span></a>
            </nav>
            <div class="pt-4 mt-4 border-t border-white/10">
                <div class="px-3 pb-2 text-[10.5px] font-bold tracking-wide text-slate-500">ENTORNO DE DEMOSTRACIÓN</div>
                <a href="login.jsp" class="nav-link" onclick="renovaCerrarSesion()"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg><span>Cerrar sesión</span></a>
            </div>
        </aside>
        <div class="flex-1 flex flex-col">
        <header class="flex items-center justify-between px-8 py-4 bg-white border-b border-gray-200">
            <div class="text-sm text-gray-500">
                <span>RenovaTech</span>
                <span class="mx-1.5">&rsaquo;</span>
                <span class="text-gray-800 font-medium">Carrito de compras</span>
            </div>
            <div class="flex items-center gap-4">
                <span id="fechaActual" class="text-sm text-gray-400"></span>
                <div class="h-6 w-px bg-gray-200"></div>
                <div class="flex items-center gap-2">
                    <div id="userIniciales" class="avatar-circle">JV</div>
                    <div class="leading-tight">
                        <div id="userNombre" class="text-sm font-semibold text-gray-800">JORDAN VERA</div>
                        <div id="userRol" class="text-xs text-gray-400">Administrador</div>
                    </div>
                </div>
            </div>
        </header>
            <main class="flex-1 px-8 py-8">

                <div class="mb-6">
                    <h1 class="text-2xl font-bold text-gray-900">Carrito de compras</h1>
                    <p class="text-sm text-gray-500 mt-1">Revisa tus productos antes de finalizar la compra.</p>
                </div>

                <div id="avisos"></div>

                <div id="carritoVacio" class="card-white p-12 text-center" style="display:none">
                    <div class="text-gray-300 mb-3 flex justify-center"><svg xmlns="http://www.w3.org/2000/svg" width="56" height="56" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"/></svg></div>
                    <h2 class="text-lg font-semibold text-gray-800">Tu carrito está vacío</h2>
                    <p class="text-sm text-gray-500 mt-1 mb-5">Agrega productos desde el catálogo para comprarlos.</p>
                    <a href="catalogo.jsp" class="inline-block px-5 py-3 btn-primary-upla text-white rounded-xl text-sm font-medium shadow-sm">Ver catálogo</a>
                </div>

                <div id="carritoLleno" class="grid grid-cols-1 lg:grid-cols-[2fr_1fr] gap-6" style="display:none">
                    <div class="card-white overflow-hidden h-fit">
                        <table class="data-table">
                            <thead><tr><th>Imagen</th><th>Producto</th><th>Precio</th><th>Cantidad</th><th>Subtotal</th><th></th></tr></thead>
                            <tbody id="tbodyCarrito"></tbody>
                        </table>
                    </div>

                    <div class="card-white p-6 h-fit">
                        <h3 class="text-base font-semibold text-gray-900 mb-4">Resumen de la compra</h3>
                        <div class="flex justify-between text-sm text-gray-600 mb-2"><span>Productos</span><span id="resLineas">0</span></div>
                        <div class="flex justify-between text-sm text-gray-600 mb-2"><span>Unidades</span><span id="resUnidades">0</span></div>
                        <div class="flex justify-between items-center border-t border-gray-100 pt-3 mt-3 mb-5">
                            <span class="font-semibold text-gray-800">Total a pagar</span>
                            <span id="resTotal" class="text-xl font-bold text-gray-900">S/ 0.00</span>
                        </div>

                        <div class="pay-title">Elige cómo quieres pagar</div>
                        <div class="pay-options" role="radiogroup" aria-label="Método de pago">
                          <button type="button" class="pay-option" data-pay="Efectivo contra entrega" aria-pressed="false"><span class="pay-icon cash">S/</span><span><b>Efectivo contra entrega</b><small>Pagas cuando recibes tu pedido</small></span><span class="pay-check">✓</span></button>
                          <button type="button" class="pay-option selected" data-pay="Tarjeta de crédito o débito" aria-pressed="true"><span class="pay-icon">▣</span><span><b>Tarjeta de débito/crédito</b><small>Visa, Mastercard u otra</small></span><span class="pay-check">✓</span></button>
                          <button type="button" class="pay-option" data-pay="Yape / Plin" aria-pressed="false"><span class="pay-icon yape">Y</span><span><b>Yape / Plin</b><small>Celular y número de operación</small></span><span class="pay-check">✓</span></button>
                          <button type="button" class="pay-option" data-pay="Transferencia bancaria" aria-pressed="false"><span class="pay-icon">⇄</span><span><b>Transferencia bancaria</b><small>Banco y código de operación</small></span><span class="pay-check">✓</span></button>
                        </div>
                        <input type="hidden" id="metodoPago" value="Tarjeta de crédito o débito">
                        <div id="datosPago" class="payment-fields">
                          <div id="camposEfectivo" class="pay-panel" hidden><div class="cash-delivery-note"><span class="cash-delivery-symbol">S/</span><div><strong>Pagas al recibir</strong><p>Prepara el importe exacto o consulta al repartidor si dispone de sencillo. El pedido quedará registrado como pago contra entrega.</p></div></div></div>
                          <div id="camposTarjeta" class="pay-panel">
                            <label for="titularTarjeta">Titular de la tarjeta</label><input id="titularTarjeta" autocomplete="cc-name" placeholder="Nombre como aparece en la tarjeta" maxlength="100">
                            <label for="numeroTarjeta">Número de tarjeta</label><input id="numeroTarjeta" inputmode="numeric" autocomplete="cc-number" placeholder="1234 5678 9012 3456" maxlength="23">
                            <div class="pay-two"><div><label for="vencimientoTarjeta">Vencimiento (MM/AA)</label><input id="vencimientoTarjeta" autocomplete="cc-exp" placeholder="MM/AA" maxlength="5"></div><div><label for="cvvTarjeta">CVV</label><input id="cvvTarjeta" inputmode="numeric" autocomplete="cc-csc" placeholder="123" maxlength="4" type="password"></div></div>
                            <p class="pay-hint">Demo académica: no se procesa ningún cobro real. Nunca guardamos el CVV ni el número completo.</p>
                          </div>
                          <div id="camposYape" class="pay-panel" hidden><label for="telefonoYape">Número de celular asociado a Yape / Plin</label><input id="telefonoYape" inputmode="numeric" placeholder="9XXXXXXXX" maxlength="9"><label for="operacionYape">Código de operación (si ya pagaste)</label><input id="operacionYape" placeholder="N.º de operación o referencia" maxlength="60"><p class="pay-hint">La compra quedará registrada para verificación; esta página no confirma el pago con Yape/Plin.</p></div>
                          <div id="camposBanco" class="pay-panel" hidden><label for="bancoTransferencia">Banco de origen</label><select id="bancoTransferencia"><option value="">Selecciona tu banco</option><option>BCP</option><option>BBVA</option><option>Interbank</option><option>Scotiabank</option><option>Banco de la Nación</option><option>Otro</option></select><label for="operacionBanco">Código de operación / referencia</label><input id="operacionBanco" placeholder="Código de transferencia" maxlength="60"><p class="pay-hint">La compra quedará pendiente de verificación de la transferencia.</p></div>
                        </div>

                        <div id="compraError" class="bg-red-50 border border-red-200 text-red-700 text-sm px-4 py-3 rounded-lg mb-4" style="display:none"></div>

                        <button id="btnFinalizar" class="w-full px-5 py-3 btn-primary-upla text-white rounded-xl text-sm font-semibold shadow-sm">Finalizar compra</button>
                        <a href="catalogo.jsp" class="block text-center text-sm text-blue-600 font-medium mt-3">Seguir comprando</a>
                        <p class="text-xs text-gray-400 mt-4">El stock se descuenta al confirmar la compra.</p>
                    </div>
                </div>

                <div id="modalCompra" class="modal-backdrop">
                    <div class="modal-box">
                        <h3 class="text-lg font-bold text-gray-900 mb-1">¿Confirmar tu compra?</h3>
                        <p class="text-sm text-gray-500 mb-4">Revisa el resumen. Al confirmar se registrará el pedido y se descontará el stock.</p>
                        <div class="bg-gray-50 border border-gray-200 rounded-xl p-4 mb-5 text-sm">
                            <div class="flex justify-between mb-1"><span class="text-gray-500">Unidades</span><span id="mcUnidades" class="font-semibold text-gray-800"></span></div>
                            <div class="flex justify-between mb-1"><span class="text-gray-500">Método de pago</span><span id="mcMetodo" class="font-semibold text-gray-800"></span></div>
                            <div class="flex justify-between"><span class="text-gray-500">Total</span><span id="mcTotal" class="font-bold text-gray-900"></span></div>
                        </div>
                        <div class="flex justify-end gap-3">
                            <button id="btnCancelarCompra" class="px-5 py-2.5 border border-gray-300 rounded-xl text-sm font-medium text-gray-600 hover:bg-gray-50">Cancelar</button>
                            <button id="btnConfirmarCompra" class="px-5 py-2.5 btn-primary-upla text-white rounded-xl text-sm font-medium">Confirmar compra</button>
                        </div>
                    </div>
                </div>

            </main>
        </div>
    </div>

    <script>
        document.getElementById("fechaActual").textContent = "Fecha actual: " + renovaFechaActual();
        renovaAplicarRol();
    </script>
    <script>
        function render() {
            const d = renovaDetalleCarrito();
            document.getElementById("avisos").innerHTML = d.avisos.map(a =>
                '<div class="bg-amber-50 border border-amber-200 text-amber-800 text-sm px-4 py-3 rounded-lg mb-3">' + renovaEsc(a) + '</div>').join("");
            const vacio = d.lineas.length === 0;
            document.getElementById("carritoVacio").style.display = vacio ? "" : "none";
            document.getElementById("carritoLleno").style.display = vacio ? "none" : "";
            if (vacio) { return; }

            document.getElementById("tbodyCarrito").innerHTML = d.lineas.map(l => {
                const p = l.producto;
                const cod = renovaEsc(p.codigo);
                return '<tr>' +
                    '<td>' + renovaThumb(p) + '</td>' +
                    '<td><div class="font-semibold text-gray-800">' + renovaEsc(p.nombre) + '</div><div class="text-xs text-gray-400">' + cod + ' · Stock: ' + p.stock + '</div></td>' +
                    '<td>S/ ' + Number(p.precio).toFixed(2) + '</td>' +
                    '<td><div class="qty"><button type="button" data-acc="menos" data-cod="' + cod + '">&minus;</button><span>' + l.cantidad + '</span>' +
                        '<button type="button" data-acc="mas" data-cod="' + cod + '"' + (l.cantidad >= p.stock ? " disabled" : "") + '>+</button></div></td>' +
                    '<td class="font-semibold text-gray-800">S/ ' + l.subtotal.toFixed(2) + '</td>' +
                    '<td><a href="#" class="action-delete" data-acc="quitar" data-cod="' + cod + '">Quitar</a></td>' +
                    '</tr>';
            }).join("");
            document.getElementById("resLineas").textContent = d.lineas.length;
            document.getElementById("resUnidades").textContent = d.unidades;
            document.getElementById("resTotal").textContent = renovaFormatoMoneda(d.total);
        }

        document.getElementById("tbodyCarrito").addEventListener("click", function (e) {
            const el = e.target.closest("[data-acc]");
            if (!el) { return; }
            e.preventDefault();
            const cod = el.getAttribute("data-cod");
            const item = renovaGetCarrito().find(i => i.codigo === cod);
            if (!item) { render(); return; }
            const acc = el.getAttribute("data-acc");
            if (acc === "mas") { renovaCambiarCantidad(cod, item.cantidad + 1); }
            else if (acc === "menos") { renovaCambiarCantidad(cod, item.cantidad - 1); }
            else { renovaQuitarDelCarrito(cod); }
            render();
        });

        const modal = document.getElementById("modalCompra");
        const errorBox = document.getElementById("compraError");
        const payOptions = Array.from(document.querySelectorAll(".pay-option"));
        function selectPay(method) {
            document.getElementById("metodoPago").value = method;
            payOptions.forEach(b => { const on = b.dataset.pay === method; b.classList.toggle("selected", on); b.setAttribute("aria-pressed", String(on)); });
            document.getElementById("camposEfectivo").hidden = method !== "Efectivo contra entrega";
            document.getElementById("camposTarjeta").hidden = method !== "Tarjeta de crédito o débito";
            document.getElementById("camposYape").hidden = method !== "Yape / Plin";
            document.getElementById("camposBanco").hidden = method !== "Transferencia bancaria";
            errorBox.style.display = "none";
        }
        payOptions.forEach(b => b.addEventListener("click", () => selectPay(b.dataset.pay)));
        function paymentPayload() {
            const method = document.getElementById("metodoPago").value;
            const v = id => document.getElementById(id).value.trim();
            const p = { metodo: method };
            if (method === "Efectivo contra entrega") {
                p.referencia = "Pago en efectivo al recibir el pedido";
            } else if (method === "Tarjeta de crédito o débito") {
                const number = v("numeroTarjeta").replace(/\D/g, "");
                if (v("titularTarjeta").length < 3 || number.length < 13 || number.length > 19 || !/^([0-9]{2})\/([0-9]{2})$/.test(v("vencimientoTarjeta")) || !/^[0-9]{3,4}$/.test(v("cvvTarjeta"))) return {error:"Completa los datos de la tarjeta. Revisa titular, número, vencimiento y CVV."};
                const parts = v("vencimientoTarjeta").split("/"); const month = Number(parts[0]);
                if (month < 1 || month > 12) return {error:"El mes de vencimiento de la tarjeta no es válido."};
                p.titular = v("titularTarjeta"); p.ultimos4 = number.slice(-4); p.referencia = "Vencimiento " + v("vencimientoTarjeta");
                // CVV and full card number are intentionally never sent to the server or stored.
            } else if (method === "Yape / Plin") {
                if (!/^9[0-9]{8}$/.test(v("telefonoYape"))) return {error:"Ingresa un celular peruano válido de 9 dígitos para Yape / Plin."};
                if (v("operacionYape").length < 3) return {error:"Ingresa el código de operación o referencia de Yape / Plin."};
                p.telefono = v("telefonoYape"); p.referencia = v("operacionYape");
            } else if (method === "Transferencia bancaria") {
                if (!v("bancoTransferencia")) return {error:"Selecciona el banco desde el que realizaste la transferencia."};
                if (v("operacionBanco").length < 3) return {error:"Ingresa el código de operación de la transferencia."};
                p.banco = v("bancoTransferencia"); p.referencia = v("operacionBanco");
            }
            return {data:p};
        }
        document.getElementById("btnFinalizar").addEventListener("click", function () {
            errorBox.style.display = "none";
            const d = renovaDetalleCarrito();
            if (!d.lineas.length) { render(); return; }
            const payment = paymentPayload();
            if (payment.error) { errorBox.textContent = payment.error; errorBox.style.display = ""; return; }
            document.getElementById("mcUnidades").textContent = d.unidades;
            document.getElementById("mcMetodo").textContent = document.getElementById("metodoPago").value;
            document.getElementById("mcTotal").textContent = renovaFormatoMoneda(d.total);
            modal.dataset.payment = JSON.stringify(payment.data);
            modal.classList.add("open");
        });
        document.getElementById("btnCancelarCompra").addEventListener("click", function () { modal.classList.remove("open"); });
        document.getElementById("btnConfirmarCompra").addEventListener("click", async function () {
            const btn = this; btn.disabled = true; btn.textContent = "Registrando compra…";
            const payment = JSON.parse(modal.dataset.payment || "{}");
            const r = await renovaFinalizarCompra(payment);
            btn.disabled = false; btn.textContent = "Confirmar compra";
            if (r.ok) { modal.classList.remove("open");
                window.location.href = "pedidos.jsp?nuevo=" + encodeURIComponent(r.pedido.id);
            } else {
                errorBox.textContent = r.mensaje;
                errorBox.style.display = "";
                render();
            }
        });

        render();
    </script>
</body>
</html>
