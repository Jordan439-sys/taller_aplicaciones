<%@ page contentType="text/html;charset=UTF-8" language="java" isELIgnored="true" %>
<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Iniciar sesión - RenovaTech</title>
        <script src="https://cdn.tailwindcss.com"></script>
        <link rel="stylesheet" href="css/estilos.css">
        <script src="js/auth.js"></script>
    </head>
    <body class="bg-[#f8fafc] min-h-screen flex items-center justify-center p-6">
        <div class="w-full max-w-4xl grid grid-cols-1 md:grid-cols-2 rounded-2xl overflow-hidden shadow-xl bg-white">

            <div class="sidebar p-10 text-white flex flex-col justify-between gap-10">
                <div>
                    <div class="flex items-center gap-3 mb-10">
                        <div class="w-11 h-11 rounded-xl bg-white/10 flex items-center justify-center">
                            <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16Z"/><polyline points="3.29 7 12 12 20.71 7"/><line x1="12" y1="22" x2="12" y2="12"/></svg>
                        </div>
                        <div>
                            <div class="font-bold text-lg leading-tight">RenovaTech</div>
                            <div class="text-slate-400 text-xs">Gestión de inventario</div>
                        </div>
                    </div>
                    <h2 class="text-2xl font-bold leading-snug mb-3">Todo tu inventario, en un solo lugar.</h2>
                    <p class="text-slate-400 text-sm">Registra, busca y consulta productos.</p>
                </div>
                <ul class="text-sm text-slate-300 space-y-2">
                    <li>&bull; <b class="text-white">Administrador:</b> gestiona productos y reportes.</li>
                    <li>&bull; <b class="text-white">Cliente:</b> se registra, elige productos y compra.</li>
                </ul>
            </div>

            <div class="p-10">
                <h1 class="text-2xl font-bold text-gray-900">Iniciar sesión</h1>
                <p class="text-sm text-gray-500 mt-1 mb-6">Elige cómo quieres entrar.</p>

                <div class="flex gap-3 mb-6">
                    <button type="button" id="btnRolAdmin" class="rol-btn active">
                        <div class="rol-titulo">Administrador</div>
                        <div class="rol-desc">Gestiona productos y reportes</div>
                    </button>
                    <button type="button" id="btnRolcliente" class="rol-btn">
                        <div class="rol-titulo">Cliente</div>
                        <div class="rol-desc">Elige y compra productos</div>
                    </button>
                </div>

                <form id="formLogin" action="login" method="post" autocomplete="off">
                    <label class="block text-sm font-semibold text-gray-700 mb-2" for="usuario">Usuario</label>
                    <input type="hidden" id="rol" name="rol" value="administrador">
                    <input type="text" id="usuario" name="usuario" class="w-full px-4 py-3 rounded-lg border border-gray-300 outline-none focus:ring-2 focus:ring-blue-500 text-gray-800 mb-4" placeholder="admin">

                    <label class="block text-sm font-semibold text-gray-700 mb-2" for="clave">Contraseña</label>
                    <input type="password" id="clave" name="clave" class="w-full px-4 py-3 rounded-lg border border-gray-300 outline-none focus:ring-2 focus:ring-blue-500 text-gray-800 mb-4" placeholder="••••••••">

                    <div id="loginError" class="hidden bg-red-50 border border-red-200 text-red-700 text-sm px-4 py-3 rounded-lg mb-4"></div>

                    <button type="submit" class="w-full px-5 py-3 btn-primary-upla text-white rounded-xl text-sm font-semibold shadow-sm">Ingresar</button>
                </form>
                <div id="seccionCrearCuenta" class="text-center text-sm text-gray-500 mt-4">
                    <p class="text-center text-sm text-gray-500 mt-4">¿Eres nuevo? <a href="registro.jsp" class="text-blue-600 font-semibold"> Crear cuenta </a></p>
                </div>
                <div class="card-blue p-4 mt-6 text-xs text-gray-600">
                    <div class="font-bold text-blue-700 mb-1">Credenciales de demostración</div>
                    <div>Administrador: <b>admin</b> / <b>admin123</b></div>
                    <div>Cliente: <b>jordanve</b> / <b>123456</b></div>
                </div>
            </div>
        </div>

        <script>
            // El login ahora se valida en el servidor contra SQL Server.
            let rolElegido = "administrador";
            const btnAdmin = document.getElementById("btnRolAdmin");
            const btncliente = document.getElementById("btnRolcliente");
            const inputUsuario = document.getElementById("usuario");
            const inputRol = document.getElementById("rol");
            const errorBox = document.getElementById("loginError");

            function elegirRol(rol) {
                rolElegido = rol;
                inputRol.value = rol;
                btnAdmin.classList.toggle("active", rol === "administrador");
                btncliente.classList.toggle("active", rol === "cliente");
                inputUsuario.placeholder = rol === "administrador" ? "admin" : "cliente";
                errorBox.classList.add("hidden");
                inputUsuario.focus();
                // NUEVO: Mostrar u ocultar "Crear cuenta" según el rol elegido
                const seccionCrear = document.getElementById("seccionCrearCuenta");
                if (seccionCrear) {
                    if (rol === "cliente") {
                        seccionCrear.style.display = "block"; // Se muestra si es cliente
                    } else {
                        seccionCrear.style.display = "none";  // Se oculta si es administrador
                    }
                }
            }

            btnAdmin.addEventListener("click", function () {
                elegirRol("administrador");
            });
            btncliente.addEventListener("click", function () {
                elegirRol("cliente");
            });

            const params = new URLSearchParams(window.location.search);
            const error = params.get("error");
            if (error === "credenciales" || error === "datos") {
                errorBox.textContent = "Usuario o contraseña incorrectos para el rol seleccionado.";
                errorBox.classList.remove("hidden");
            } else if (error === "conexion") {
                errorBox.textContent = "No se pudo conectar con la base de datos. Revisa SQL Server y la configuración de conexión.";
                errorBox.classList.remove("hidden");
            }
        </script>
    </body>
</html>
