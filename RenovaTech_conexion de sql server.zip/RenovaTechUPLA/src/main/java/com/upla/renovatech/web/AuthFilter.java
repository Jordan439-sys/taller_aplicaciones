package com.upla.renovatech.web;

import jakarta.servlet.*;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.util.Set;

@WebFilter("*.jsp")
public class AuthFilter implements Filter {

    private static final Set<String> PUBLIC = Set.of("login.jsp", "registro.jsp");

    @Override
    public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain)
            throws IOException, ServletException {

        HttpServletRequest request = (HttpServletRequest) req;
        HttpServletResponse response = (HttpServletResponse) res;

        String uri = request.getRequestURI();
        String page = uri.substring(uri.lastIndexOf('/') + 1);

        if (PUBLIC.contains(page)) {
            chain.doFilter(req, res);
            return;
        }

        HttpSession session = request.getSession(false);
        String rol = session == null ? null : (String) session.getAttribute("rol");

        if (rol == null) {
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return;
        }

        if (page.equals("carrito.jsp") && !"comprador".equals(rol)) {
            response.sendRedirect(request.getContextPath() + "/index.jsp");
            return;
        }

        if (Set.of("registrar.jsp", "editar.jsp", "eliminar.jsp", "resumen.jsp").contains(page)
                && !"administrador".equals(rol)) {
            response.sendRedirect(request.getContextPath() + "/index.jsp");
            return;
        }

        chain.doFilter(req, res);
    }
}
