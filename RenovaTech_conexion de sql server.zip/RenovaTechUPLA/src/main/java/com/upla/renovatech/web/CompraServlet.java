package com.upla.renovatech.web;

import com.upla.renovatech.config.DatabaseConnection;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import jakarta.servlet.ServletException;
import java.io.IOException;
import java.sql.*;
import java.util.*;

@WebServlet("/api/compra")
public class CompraServlet extends HttpServlet {
  private static String trim(String s){return s==null?"":s.trim();}
  private static String nullable(String s){return s==null||s.isBlank()?null:s;}
  private void send(HttpServletResponse r,int status,String body)throws IOException{r.setStatus(status);r.setContentType("application/json;charset=UTF-8");r.getWriter().write(body);}
  @Override protected void doPost(HttpServletRequest req,HttpServletResponse res)throws IOException {
    req.setCharacterEncoding("UTF-8"); HttpSession s=req.getSession(false);
    if(s==null||!"comprador".equals(s.getAttribute("rol"))||s.getAttribute("idUsuario")==null){send(res,401,"{\"error\":\"Inicia sesión como cliente para comprar.\"}");return;}
    int idUsuario=(Integer)s.getAttribute("idUsuario"); String metodo=req.getParameter("metodo");
    String titular=trim(req.getParameter("titular")), ultimos4=trim(req.getParameter("ultimos4")), telefono=trim(req.getParameter("telefono")), banco=trim(req.getParameter("banco")), referencia=trim(req.getParameter("referencia"));
    int idMetodo=switch(metodo==null?"":metodo){case "Efectivo contra entrega"->1;case "Tarjeta de crédito o débito"->2;case "Yape / Plin"->3;case "Transferencia bancaria"->4;default->0;};
    if(idMetodo==2 && (titular.length()<3 || !ultimos4.matches("[0-9]{4}") || referencia.length()>100)) {send(res,400,"{\"error\":\"Datos de tarjeta incompletos.\"}");return;}
    if(idMetodo==3 && (!telefono.matches("9[0-9]{8}") || referencia.length()<3)) {send(res,400,"{\"error\":\"Datos de Yape / Plin incompletos.\"}");return;}
    if(idMetodo==4 && (banco.isBlank() || referencia.length()<3)) {send(res,400,"{\"error\":\"Datos de transferencia incompletos.\"}");return;}
    String[] codigos=req.getParameterValues("codigo"), cantidades=req.getParameterValues("cantidad");
    if(idMetodo==0||codigos==null||cantidades==null||codigos.length==0||codigos.length!=cantidades.length){send(res,400,"{\"error\":\"El carrito o el método de pago no son válidos.\"}");return;}
    try(Connection cn=DatabaseConnection.getConnection()){
      cn.setAutoCommit(false);
      try {
        try(PreparedStatement del=cn.prepareStatement("DELETE FROM dbo.ItemCarrito WHERE IdUsuario=?")){del.setInt(1,idUsuario);del.executeUpdate();}
        try(CallableStatement add=cn.prepareCall("{call dbo.usp_AgregarAlCarrito(?,?,?)}")){
          for(int i=0;i<codigos.length;i++){int q;try{q=Integer.parseInt(cantidades[i]);}catch(Exception ex){throw new SQLException("Cantidad inválida.");} if(q<1||q>999)throw new SQLException("Cantidad inválida."); add.setInt(1,idUsuario);add.setString(2,codigos[i]);add.setInt(3,q);add.execute();}
        }
        int idPedido;
        try(CallableStatement fin=cn.prepareCall("{call dbo.usp_FinalizarCompra(?,?,?)}")){fin.setInt(1,idUsuario);fin.setByte(2,(byte)idMetodo);fin.registerOutParameter(3,Types.INTEGER);fin.execute();idPedido=fin.getInt(3);}
        String estadoPago = idMetodo == 1 ? "Pago contra entrega" : (idMetodo == 2 ? "Pendiente de pasarela" : "Pendiente de verificación");
        try(PreparedStatement pago=cn.prepareStatement("UPDATE dbo.Pedido SET TitularPago=?, Ultimos4Tarjeta=?, TelefonoPago=?, BancoPago=?, ReferenciaPago=?, EstadoPago=? WHERE IdPedido=?")) {
          pago.setString(1, nullable(titular)); pago.setString(2, nullable(ultimos4)); pago.setString(3, nullable(telefono)); pago.setString(4, nullable(banco)); pago.setString(5, nullable(referencia)); pago.setString(6, estadoPago); pago.setInt(7,idPedido); pago.executeUpdate();
        }
        cn.commit();
        String numero="PED-"+String.format(Locale.ROOT,"%04d",idPedido);
        send(res,200,"{\"ok\":true,\"idPedido\":"+idPedido+",\"pedido\":\""+numero+"\"}");
      }catch(Exception e){cn.rollback();throw e;}finally{cn.setAutoCommit(true);}
    }catch(Exception e){getServletContext().log("Error finalizando compra en SQL Server",e);String msg=e.getMessage()==null?"No se pudo registrar la compra.":e.getMessage().replace("\"","'").replace("\r"," ").replace("\n"," ");send(res,400,"{\"error\":\""+msg+"\"}");}
  }
}
