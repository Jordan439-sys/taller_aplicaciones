package com.upla.renovatech.web;

import com.upla.renovatech.config.DatabaseConnection;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import jakarta.servlet.http.Cookie;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {

    private static final String SQL = """
        SELECT u.IdUsuario, u.NombreUsuario, u.ClaveHash,
               u.NombreCompleto, u.IdRol, r.NombreRol
        FROM dbo.Usuario u
        INNER JOIN dbo.Rol r ON r.IdRol = u.IdRol
        WHERE u.NombreUsuario = ? AND u.Activo = 1
        """;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");

        String usuario = request.getParameter("usuario");
        String clave = request.getParameter("clave");
        String rol = request.getParameter("rol");

        if (usuario == null || clave == null || rol == null
                || usuario.isBlank() || clave.isBlank()) {
            response.sendRedirect("login.jsp?error=datos");
            return;
        }

        int rolEsperado = "administrador".equalsIgnoreCase(rol) ? 1 : 2;

        try (Connection cn = DatabaseConnection.getConnection(); PreparedStatement ps = cn.prepareStatement(SQL)) {

            ps.setString(1, usuario.trim());

            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) {
                    response.sendRedirect("login.jsp?error=credenciales");
                    return;
                }

                int idRol = rs.getInt("IdRol");
                byte[] hashBD = rs.getBytes("ClaveHash");
                byte[] hashIngresado = sha256Unicode(clave);

                if (idRol != rolEsperado || !MessageDigest.isEqual(hashBD, hashIngresado)) {
                    response.sendRedirect("login.jsp?error=credenciales");
                    return;
                }

                HttpSession session = request.getSession(true);
                session.setAttribute("idUsuario", rs.getInt("IdUsuario"));
                session.setAttribute("usuario", rs.getString("NombreUsuario"));
                session.setAttribute("nombre", rs.getString("NombreCompleto"));
                String rolSesion = idRol == 1 ? "administrador" : "comprador";
                session.setAttribute("rol", rolSesion);

                // Cookies no sensibles para que la interfaz JavaScript pueda mostrar el usuario/rol.
                // La autorización real siempre se valida con la HttpSession en AuthFilter.
                addCookie(response, "renova_user", rs.getString("NombreUsuario"), 1800);
                addCookie(response, "renova_name", rs.getString("NombreCompleto"), 1800);
                addCookie(response, "renova_rol", rolSesion, 1800);

                response.sendRedirect("index.jsp");
            }

        } catch (Exception e) {
            System.err.println("=== ERROR REAL ATRAPADO EN EL SERVLET ===");
            e.printStackTrace(); // Esto imprimirá el error completo en letras rojas en la consola
            getServletContext().log("Error conectando con RenovaTech", e);
            response.sendRedirect("login.jsp?error=conexion");
        }
    }

    private static void addCookie(HttpServletResponse response, String name, String value, int maxAge) {
    try {
        if (value != null) {
            // Codificamos el valor para evitar errores con espacios o tildes en las cookies
            value = java.net.URLEncoder.encode(value, java.nio.charset.StandardCharsets.UTF_8);
        }
        Cookie cookie = new Cookie(name, value);
        cookie.setMaxAge(maxAge);
        cookie.setPath("/");
        response.addCookie(cookie);
    } catch (Exception e) {
        e.printStackTrace();
    }
}

    private static byte[] sha256Unicode(String texto) throws Exception {
        // SQL Server HASHBYTES(..., N'...') sobre NVARCHAR usa UTF-16LE.
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        return md.digest(texto.getBytes(StandardCharsets.UTF_16LE));
    }
}
