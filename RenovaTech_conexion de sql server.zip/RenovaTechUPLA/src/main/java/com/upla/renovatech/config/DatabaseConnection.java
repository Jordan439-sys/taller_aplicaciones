package com.upla.renovatech.config;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/** Conexión JDBC a SQL Server. Configurar RENOVATECH_DB_URL, RENOVATECH_DB_USER y RENOVATECH_DB_PASSWORD. */
public final class DatabaseConnection {
    private DatabaseConnection() {}
    public static Connection getConnection() throws SQLException {
        String url = env("RENOVATECH_DB_URL", "jdbc:sqlserver://localhost:1433;databaseName=RenovaTech;encrypt=false;trustServerCertificate=true");
        String user = env("RENOVATECH_DB_USER", "sa");
        String password = env("RENOVATECH_DB_PASSWORD", "");
        if (password.isBlank()) throw new SQLException("Falta configurar la variable RENOVATECH_DB_PASSWORD para SQL Server.");
        try { Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver"); }
        catch (ClassNotFoundException e) { throw new SQLException("No se encontró el driver JDBC de SQL Server.", e); }
        return DriverManager.getConnection(url, user, password);
    }
    private static String env(String key, String fallback) {
        String value = System.getenv(key);
        return value == null || value.isBlank() ? fallback : value;
    }
}
