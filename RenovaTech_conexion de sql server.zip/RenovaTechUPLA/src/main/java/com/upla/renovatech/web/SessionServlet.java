package com.upla.renovatech.web;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;

@WebServlet("/auth/session")
public class SessionServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws IOException {
        response.setContentType("application/json;charset=UTF-8");

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("usuario") == null) {
            response.getWriter().print("{\"ok\":false}");
            return;
        }

        String usuario = json((String) session.getAttribute("usuario"));
        String nombre = json((String) session.getAttribute("nombre"));
        String rol = json((String) session.getAttribute("rol"));

        response.getWriter().print(
            "{\"ok\":true,\"usuario\":\"" + usuario +
            "\",\"nombre\":\"" + nombre +
            "\",\"rol\":\"" + rol + "\"}"
        );
    }

    private static String json(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\").replace("\"", "\\\"")
                .replace("\r", "\\r").replace("\n", "\\n");
    }
}
